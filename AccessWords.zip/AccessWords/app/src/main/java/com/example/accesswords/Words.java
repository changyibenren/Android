package com.example.accesswords;

import android.net.Uri;
import android.provider.BaseColumns;

import java.io.Serializable;

public class Words implements Serializable {
    //判断搜索语言
    private boolean isChinese;
    //搜索词
    private String key;
    //英文翻译
    private String fy;
    //英音发音
    private String psE;
    //英音发音的mp3地址
    private String pronE;
    //美音发音
    private String psA;
    //美音发音的mp3地址
    private String pronA;
    //单词的词性与词义
    private String posAcceptation;
    //例句
    private static String sample;
    public static final String AUTHORITY="com.example.wordslist.wordsprovider";


    public Words(){

    }

    public Words(boolean isChinese, String key, String fy, String psE,
                 String pronE, String psA, String pronA, String posAcceptation, String sample) {
        this.isChinese = isChinese;
        this.key = key;
        this.fy = fy;
        this.psE = psE;
        this.pronE = pronE;
        this.psA = psA;
        this.pronA = pronA;
        this.posAcceptation = posAcceptation;
        this.sample = sample;
    }

    public boolean getIsChinese() {
        return isChinese;
    }

    public void setIsChinese(boolean isChinese) {
        this.isChinese = isChinese;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getFy() {
        return fy;
    }

    public void setFy(String fy) {
        this.fy = fy;
    }

    public String getPsE() {
        return psE;
    }

    public void setPsE(String psE) {
        this.psE = psE;
    }

    public String getPronE() {
        return pronE;
    }

    public void setPronE(String pronE) {
        this.pronE = pronE;
    }

    public String getPsA() {
        return psA;
    }

    public void setPsA(String psA) {
        this.psA = psA;
    }

    public String getPronA() {
        return pronA;
    }

    public void setPronA(String pronA) {
        this.pronA = pronA;
    }

    public String getPosAcceptation() {
        return posAcceptation;
    }

    public void setPosAcceptation(String posAcceptation) {
        this.posAcceptation = posAcceptation;
    }

    public static String getSample(){
        return sample;
    }

    public void setSample(String sample){
        this.sample = sample;
    }


    public static abstract class Word implements BaseColumns{
        public static final String TABLE_NAME="Words";
        public static final String COLUMN_NAME_WORD="word";
        public static final String COLUMN_NAME_MEANING="posAcceptation";
        public static final String COLUMN_NAME_SAMPLE="sent";
        public static final String MIME_DIR_PREFIX="vnd.android.cursor.dir";
        public static final String MIME_ITEM_PREFIX="vnd.android.cursor.item";
        public static final String MIME_ITEM="vnd.com.example.wordslist.Words";
        public static final String MIME_TYPE_SINGLE=MIME_ITEM_PREFIX+"/"+MIME_ITEM;
        public static final String MIME_TYPE_MULTIPLE=MIME_DIR_PREFIX+"/"+MIME_ITEM;
        public static final String PATH_SINGLE="Words/#";
        public static final String PATH_MULTIPLE="Words";
        public static final String CONTENT_URI_STRING="content://"+AUTHORITY+"/"+PATH_MULTIPLE;
        public static final Uri CONTENT_URI=Uri.parse(CONTENT_URI_STRING);


    }
}
