package com.example.accesswords;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.UserDictionary;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    private static final String TAG="MYWORDSTAG";
    private ContentResolver contentResolver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        contentResolver=this.getContentResolver();
        Button buttonAll=(Button)findViewById(R.id.buttonAll);
        Button buttonInsert=(Button)findViewById(R.id.buttonInsert);
        Button buttonDelete=(Button)findViewById(R.id.buttonDelete);
        Button buttonDeleteAll=(Button)findViewById(R.id.buttonDeleteAll);
        Button buttonUpdate=(Button)findViewById(R.id.buttonUpdate);
        Button buttonQuery=(Button)findViewById(R.id.buttonQuery);
        buttonAll.setOnClickListener(this);
        buttonInsert.setOnClickListener(this);
        buttonDelete.setOnClickListener(this);
        buttonDeleteAll.setOnClickListener(this);
        buttonUpdate.setOnClickListener(this);
        buttonQuery.setOnClickListener(this);
    }

    @Override
    public void onClick(View view){
        switch (view.getId()){
            case R.id.buttonAll:
                //Uri uri=Uri.parse("content://com.example.wordslist/Words");
                Cursor cursor = contentResolver.query(Words.Word.CONTENT_URI,
                        new String[] { Words.Word._ID, Words.Word.COLUMN_NAME_WORD,Words.Word.COLUMN_NAME_MEANING,Words.Word.COLUMN_NAME_SAMPLE},
                        null, null, null);
                if (cursor == null){
                    Toast.makeText(MainActivity.this,"没有找到记录",Toast.LENGTH_LONG).show();
                    return;
                }

                String msg = "";
                if (cursor.moveToFirst()){//找到记录，这里简单起见，使用Log输出
                    do{
                        msg += "ID:" + cursor.getInt(cursor.getColumnIndex(Words.Word._ID)) + ",";
                        msg += "单词：" + cursor.getString(cursor.getColumnIndex(Words.Word.COLUMN_NAME_WORD))+ ",";
                        msg += "含义：" + cursor.getString(cursor.getColumnIndex(Words.Word.COLUMN_NAME_MEANING)) + ",";
                        msg += "示例" + cursor.getString(cursor.getColumnIndex(Words.Word.COLUMN_NAME_SAMPLE)) + "\n";
                    }while(cursor.moveToNext());
                    cursor.close();
                }

                Log.v(TAG,msg);
                break;
            case R.id.buttonInsert:
                String strWord="Banana";
                String strMeaning="banana";
                String strSample="This banana is very nice.";
                ContentValues values = new ContentValues();
                values.put(Words.Word.COLUMN_NAME_WORD, strWord);
                values.put(Words.Word.COLUMN_NAME_MEANING, strMeaning);
                values.put(Words.Word.COLUMN_NAME_SAMPLE, strSample);

                Uri newUri = contentResolver.insert(Words.Word.CONTENT_URI, values);
                break;
            case R.id.buttonDelete:
                String id="3";//简单起见，这里指定ID，用户可在程序中设置id的实际值
                Uri uri = Uri.parse(Words.Word.CONTENT_URI_STRING + "/" + id);
                int result = contentResolver.delete(uri, null, null);
                break;
            case R.id.buttonDeleteAll:
                contentResolver.delete(Words.Word.CONTENT_URI, null, null);
                break;
            case R.id.buttonUpdate:
                String uid="2";
                String ustrWord="Ban";
                String ustrMeaning="banana";
                String ustrSample="This banana is very nice.";
                ContentValues uvalues = new ContentValues();

                uvalues.put(Words.Word.COLUMN_NAME_WORD, ustrWord);
                uvalues.put(Words.Word.COLUMN_NAME_MEANING, ustrMeaning);
                uvalues.put(Words.Word.COLUMN_NAME_SAMPLE, ustrSample);

                Uri uuri = Uri.parse(Words.Word.CONTENT_URI_STRING + "/" + uid);
                int uresult = contentResolver.update(uuri, uvalues, null, null);
                break;
            case R.id.buttonQuery:
                String qid="2";
                Uri quri = Uri.parse(Words.Word.CONTENT_URI_STRING + "/" + qid);
                Cursor qcursor = contentResolver.query(quri,
                        new String[] { Words.Word._ID, Words.Word.COLUMN_NAME_WORD, Words.Word.COLUMN_NAME_MEANING,Words.Word.COLUMN_NAME_SAMPLE},
                        null, null, null);
                if (qcursor == null){
                    Toast.makeText(MainActivity.this,"没有找到记录",Toast.LENGTH_LONG).show();
                    return;
                }
                //找到记录，这里简单起见，使用Log输出
                String qmsg = "";
                if (qcursor.moveToFirst()){
                    do{
                        qmsg += "ID:" + qcursor.getInt(qcursor.getColumnIndex(Words.Word._ID)) + ",";
                        qmsg += "单词：" + qcursor.getString(qcursor.getColumnIndex(Words.Word.COLUMN_NAME_WORD))+ ",";
                        qmsg += "含义：" + qcursor.getString(qcursor.getColumnIndex(Words.Word.COLUMN_NAME_MEANING)) + ",";
                        qmsg += "示例" + qcursor.getString(qcursor.getColumnIndex(Words.Word.COLUMN_NAME_SAMPLE)) + "\n";
                    }while(qcursor.moveToNext());
                }
                Log.v(TAG,qmsg);
                break;
        }
    }
}
