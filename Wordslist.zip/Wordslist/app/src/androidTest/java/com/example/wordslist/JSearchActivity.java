package com.example.wordslist;


import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Button;


import androidx.appcompat.app.ActionBar;
import androidx.appcompat.widget.Toolbar;

import com.example.wordslist.R;

import static com.example.wordslist.Util.ParseXML.parseJinshanChineseToEnglishXMLWithPull;

public class JSearchActivity extends BaseActivity{

    private static final String TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jsearch);

        Toolbar toolbar = (Toolbar) this.findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);       //使用Toolbar

        ActionBar actionBar = getSupportActionBar();  //获取ActionBar实例,具体实现由Toolbar完成
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);          //显示导航按钮设置为true
        }

        Button translation = (Button) findViewById(R.id.btn_translate);

        //translation.setOnClickListener(this);

    }



    //为按钮设置点击事件
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {

            case android.R.id.home:
                //退出程序逻辑
                break;

            default:
        }
        return true;
    }

}
