package com.example.wordslist.Util;

import java.io.InputStream;

public interface HttpCallBackListener {
    void onFinish(InputStream inputStream);
    void onError();
}
