package com.example.wordslist.Fragments;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;

import android.app.Fragment;

import android.util.Log;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewStub;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.wordslist.Activity.MainActivity;
import com.example.wordslist.Activity.NewsActivity;
import com.example.wordslist.Activity.SearchActivity;
import com.example.wordslist.Beans.Words;
import com.example.wordslist.Database.OpenHelper;
import com.example.wordslist.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link Wordslist.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link Wordslist#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Wordslist extends Fragment{
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    OpenHelper openHelper;
    ListView wlist;

    private OnFragmentInteractionListener mListener;

    public Wordslist() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment Wordslist.
     */
    // TODO: Rename and change types and number of parameters
    public static Wordslist newInstance(String param1, String param2) {
        Wordslist fragment = new Wordslist();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View wordsList=inflater.inflate(R.layout.fragment_wordslist, container, false);
        wlist=(ListView)wordsList.findViewById(R.id.wlist);
        //registerForContextMenu(wlist);
        openHelper=new OpenHelper(this.getActivity(),"wordsdb",null,2);
        ArrayList<Map<String,String>> items=getAll();
        setWordsListView(items);
        setHasOptionsMenu(true);
        registerForContextMenu(wlist);
        //TextView textView=(TextView)wordsList.findViewById(R.id.textView2);
        return wordsList;
    }



    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other com.example.wordslist.Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }



    public void onDestory(){
        super.onDestroy();
        openHelper.close();
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {

        inflater.inflate(R.menu.menu_main, menu);
        super.onCreateOptionsMenu(menu, inflater);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        int id=item.getItemId();
        switch (id){
            case R.id.action_search:
                SearchDialog();
                return true;
            case R.id.action_insert:
                InsertDialog();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void InsertUserSql(String strWord,String strMeaning,String strSample){
        String sql="insert into  Words(word,posAcceptation,sent) values(?,?,?)";

        //Gets the data repository in write mode*/
        SQLiteDatabase db = openHelper.getWritableDatabase();
        db.execSQL(sql,new String[]{strWord,strMeaning,strSample});
    }

    private void Insert(String strWord, String strMeaning, String strSample) {

        //Gets the data repository in write mode*/
        SQLiteDatabase db = openHelper.getWritableDatabase();

        // Create a new map of values, where column names are the keys
        ContentValues values = new ContentValues();
        values.put("word", strWord);
        values.put("posAcceptation", strMeaning);
        values.put("sent", strSample);

        // Insert the new row, returning the primary key value of the new row
        long newRowId;
        newRowId = db.insert(
                Words.Word.TABLE_NAME,
                null,
                values);
    }

    private void InsertDialog() {
        final TableLayout tableLayout = (TableLayout)this.getActivity().getLayoutInflater().inflate(R.layout.insert, null);
        new AlertDialog.Builder(this.getActivity())
                .setTitle("新增单词")//标题
                .setView(tableLayout)//设置视图
                //确定按钮及其动作
                .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        String strWord=((EditText)tableLayout.findViewById(R.id.txtWord)).getText().toString();
                        String strMeaning=((EditText)tableLayout.findViewById(R.id.txtMeaning)).getText().toString();
                        String strSample=((EditText)tableLayout.findViewById(R.id.txtSample)).getText().toString();

                        //既可以使用Sql语句插入，也可以使用使用insert方法插入
                        // InsertUserSql(strWord, strMeaning, strSample);
                        Insert(strWord, strMeaning, strSample);
                        ArrayList<Map<String, String>> items=getAll();
                        setWordsListView(items);
                    }
                })
                //取消按钮及其动作
                .setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                })
                .create()//创建对话框
                .show();//显示对话框
    }



    //public void OnCreateContextMenu(ContextMenu menu,View v, ContextMenu.ContextMenuInfo menuInfo) {
       // super.onCreateContextMenu(menu, v, menuInfo);
        //MenuInflater inflater = getActivity().getMenuInflater();
        //inflater.inflate(R.menu.contextmenu_wordslistview, menu);
   // }

    private void DeleteUseSql(String strId) {
        String sql="delete from words where _id='"+strId+"'";

        //Gets the data repository in write mode*/
        SQLiteDatabase db = openHelper.getReadableDatabase();
        db.execSQL(sql);
    }

    private void Delete(String strId) {
        SQLiteDatabase db = openHelper.getReadableDatabase();
        // 定义where子句
        String selection = Words.Word._ID + " = ?";

        // 指定占位符对应的实际参数
        String[] selectionArgs = {strId};

        // Issue SQL statement.
        db.delete(Words.Word.TABLE_NAME, selection, selectionArgs);
    }

    private void DeleteDialog(final String strId){
        new AlertDialog.Builder(this.getActivity()).setTitle("删除单词").setMessage("是否真的删除单词?").setPositiveButton("确定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                //既可以使用Sql语句删除，也可以使用使用delete方法删除
                DeleteUseSql(strId);
                //Delete(strId);
                setWordsListView(getAll());
            }
        }).setNegativeButton("取消", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        }).create().show();
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu,View v,ContextMenu.ContextMenuInfo menuInfo){
        super.onCreateContextMenu(menu, v, menuInfo);
        menu.add(Menu.NONE, 111, Menu.NONE, "delete");
        menu.add(Menu.NONE, 222, Menu.NONE, "update");
        menu.add(Menu.NONE, 333, Menu.NONE, "add");
        //menuInflater.inflate(R.menu.contextmenu_wordslistview,menu);
    }


    @Override
    public boolean onContextItemSelected(MenuItem item) {
        TextView id = null;
        TextView word = null;
        TextView meaning = null;
        TextView sample = null;
        AdapterView.AdapterContextMenuInfo info = null;
        View itemView = null;
        switch (item.getItemId()) {
            case 111:
                info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
                itemView = info.targetView;
                id = (TextView) itemView.findViewById(R.id.textId);
                if (id != null) {
                    String strId = id.getText().toString();
                    DeleteDialog(strId);
                }
                break;
            case 222:
                info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
                itemView = info.targetView;
                id = (TextView) itemView.findViewById(R.id.textId);
                word = (TextView) itemView.findViewById(R.id.textViewWord);
                meaning = (TextView) itemView.findViewById(R.id.textViewMeaning);
                sample = (TextView) itemView.findViewById(R.id.textViewSample);
                if (id != null && word != null && meaning != null && sample != null) {
                    String strId = id.getText().toString();
                    String strWord = word.getText().toString();
                    String strMeaning = meaning.getText().toString();
                    String strSample = sample.getText().toString();
                    UpdateDialog(strId, strWord, strMeaning, strSample);
                }
                break;
            case 333:
                info=(AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
                //int q=(int) info.id;
                final View itemView1 = info.targetView;
                // final LinearLayout linearLayout = (LinearLayout)this.getLayoutInflater().inflate(R.layout.select_item, null);
                AlertDialog.Builder builder=new AlertDialog.Builder(getActivity());
                builder.setTitle("提示").setMessage("是否将单词添加到生词本");
                builder.setPositiveButton("是", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String strWord=((TextView)itemView1.findViewById(R.id.textViewWord)).getText().toString();
                        String strMeaning=((TextView)itemView1.findViewById(R.id.textViewMeaning)).getText().toString();
                        String strSample=((TextView)itemView1.findViewById(R.id.textViewSample)).getText().toString();

                        //既可以使用Sql语句插入，也可以使用使用insert方法插入
                        // InsertUserSql(strWord, strMeaning, strSample);
                        UInsert(strWord, strMeaning, strSample);
                        Toast.makeText(getActivity(),"插入成功",Toast.LENGTH_LONG).show();
                        //Unknownwords unknownwords = new Unknownwords();
                        //unknownwords.setArguments(bundle);

                    }
                });
                builder.setNegativeButton("否", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                builder.show();
                break;
        }
        return true;
    }

    private void UInsertUserSql(String strWord,String strMeaning,String strSample){
        String sql="insert into  UWords(word,posAcceptation,sample) values(?,?,?)";

        //Gets the data repository in write mode*/
        SQLiteDatabase db = openHelper.getWritableDatabase();
        db.execSQL(sql,new String[]{strWord,strMeaning,strSample});
    }

    private void UInsert(String strWord, String strMeaning, String strSample) {

        //Gets the data repository in write mode*/
        SQLiteDatabase db = openHelper.getWritableDatabase();

        // Create a new map of values, where column names are the keys
        ContentValues values = new ContentValues();
        values.put("word", strWord);
        values.put("posAcceptation", strMeaning);
        values.put("sample", strSample);

        // Insert the new row, returning the primary key value of the new row
        long newRowId;
        newRowId = db.insert(
                Words.Word.NEWTABLE_NAME,
                null,
                values);
    }

    //使用Sql语句更新单词
    private void UpdateUseSql(String strId,String strWord, String strMeaning, String strSample) {
        SQLiteDatabase db = openHelper.getReadableDatabase();
        String sql="update Words set word=?,posAcceptation=?,sent=? where _id=?";
        db.execSQL(sql, new String[]{strWord, strMeaning, strSample,strId});
    }

    //使用方法更新
    private void Update(String strId,String strWord, String strMeaning, String strSample) {
        SQLiteDatabase db = openHelper.getReadableDatabase();


        // New value for one column
        ContentValues values = new ContentValues();
        values.put(Words.Word.COLUMN_NAME_WORD, strWord);
        values.put(Words.Word.COLUMN_NAME_MEANING, strMeaning);
        values.put(Words.Word.COLUMN_NAME_SAMPLE, strSample);

        String selection = Words.Word._ID + " = ?";
        String[] selectionArgs = {strId};

        int count = db.update(
                Words.Word.TABLE_NAME,
                values,
                selection,
                selectionArgs);
    }

    //修改对话框
    private void UpdateDialog(final String strId, final String strWord, final String strMeaning, final String strSample) {
        final TableLayout tableLayout = (TableLayout)this.getActivity().getLayoutInflater().inflate(R.layout.insert, null);
        ((EditText)tableLayout.findViewById(R.id.txtWord)).setText(strWord);
        ((EditText)tableLayout.findViewById(R.id.txtMeaning)).setText(strMeaning);
        ((EditText)tableLayout.findViewById(R.id.txtSample)).setText(strSample);
        new AlertDialog.Builder(this.getActivity())
                .setTitle("修改单词")//标题
                .setView(tableLayout)//设置视图
                //确定按钮及其动作
                .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        String strNewWord = ((EditText) tableLayout.findViewById(R.id.txtWord)).getText().toString();
                        String strNewMeaning = ((EditText) tableLayout.findViewById(R.id.txtMeaning)).getText().toString();
                        String strNewSample = ((EditText) tableLayout.findViewById(R.id.txtSample)).getText().toString();

                        //既可以使用Sql语句更新，也可以使用使用update方法更新
                        UpdateUseSql(strId, strNewWord, strNewMeaning, strNewSample);
                        //  Update(strId, strNewWord, strNewMeaning, strNewSample);
                        setWordsListView(getAll());
                    }
                })
                //取消按钮及其动作
                .setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                })
                .create()//创建对话框
                .show();//显示对话框
    }




    private void setWordsListView(ArrayList<Map<String,String>> items){
        SimpleAdapter adapter = new SimpleAdapter(this.getActivity(),items,R.layout.word_item,new
                String[]{ Words.Word._ID,"word","posAcceptation",
                "sent"},new int[]{R.id.textId,R.id.textViewWord,R.id.textViewMeaning,
                R.id.textViewSample});//listitem
        wlist.setAdapter(adapter);
    }

    private ArrayList<Map<String, String>> getAll() {
        ArrayList<Map<String, String>> list = new ArrayList<>();
        SQLiteDatabase db = openHelper.getReadableDatabase();
        Cursor c = db.query("Words", null, null, null, null, null, null);
        int colums = c.getColumnCount();
        while(c.moveToNext()){
            Map<String, String> map = new HashMap<String, String>();
            for (int i = 0; i < colums; i++) {
                String word1 = c.getColumnName(i);
                String value1 = c.getString(c.getColumnIndex(word1));
                map.put(word1, value1);
            }
            list.add(map);
        }
        return list;
    }

    //使用Sql语句查找
    private ArrayList<Map<String, String>> SearchUseSql(String strWordSearch) {
        SQLiteDatabase db = openHelper.getReadableDatabase();

        String sql="select * from Words where word like ? order by word desc";
        Cursor c=db.rawQuery(sql,new String[]{"%"+strWordSearch+"%"});

        return ConvertCursor2List(c);
    }

    //使用query方法查找
    private ArrayList<Map<String, String>> Search(String strWordSearch) {
        SQLiteDatabase db = openHelper.getReadableDatabase();

        String[] projection = {
                Words.Word._ID,
                Words.Word.COLUMN_NAME_WORD,
                Words.Word.COLUMN_NAME_MEANING,
                Words.Word.COLUMN_NAME_SAMPLE
        };

        String sortOrder =
                Words.Word.COLUMN_NAME_WORD + " DESC";

        String selection = Words.Word.COLUMN_NAME_WORD + " LIKE ?";
        String[] selectionArgs = {"%"+strWordSearch+"%"};

        Cursor c = db.query(
                Words.Word.TABLE_NAME,  // The table to query
                projection,                              // The columns to return
                selection,                              // The columns for the WHERE clause
                selectionArgs,                            // The values for the WHERE clause
                null,                              // don't group the rows
                null,                              // don't filter by row groups
                sortOrder                              // The sort order
        );

        return ConvertCursor2List(c);
    }

    //查询对话框
    private void SearchDialog() {
        final TableLayout tableLayout = (TableLayout)this.getActivity().getLayoutInflater().inflate(R.layout.searchterm, null);
        new AlertDialog.Builder(this.getActivity())
                .setTitle("查找单词")//标题
                .setView(tableLayout)//设置视图
                //确定按钮及其动作
                .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        String txtSearchWord=((EditText)tableLayout.findViewById(R.id.txtSearchWord)).getText().toString();

                        ArrayList<Map<String, String>> items=null;
                        //既可以使用Sql语句查询，也可以使用方法查询
                        items=SearchUseSql(txtSearchWord);

                        if(items.size()>0) {
                            Bundle bundle=new Bundle();
                            bundle.putSerializable("result",items);
                            Intent intent=new Intent(getActivity(), SearchActivity.class);
                            intent.putExtras(bundle);
                            startActivity(intent);
                        }else
                            Toast.makeText(getActivity(),"没有找到", Toast.LENGTH_LONG).show();
                    }
                })
                //取消按钮及其动作
                .setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                })
                .create()//创建对话框
                .show();//显示对话框
    }

    private ArrayList<Map<String,String>> ConvertCursor2List(Cursor cursor){
        ArrayList<Map<String,String>> arrayList=new ArrayList<Map<String,String>>();
        while(cursor.moveToNext()) {
            Map<String, String> map = new HashMap<String, String>();
            map.put("word", cursor.getString(2));
            map.put("posAcceptation", cursor.getString(8));
            map.put("sent", cursor.getString(9));
            arrayList.add(map);
        }
        return arrayList;
    }





}
