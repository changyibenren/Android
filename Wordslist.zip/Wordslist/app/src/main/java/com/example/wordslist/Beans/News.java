package com.example.wordslist.Beans;

public class News {
    private String news_title;   //新闻标题
    private String desc;        //新闻概要
   // private String newsTime;    //新闻时间与来源
    private String path;        //新闻路径
    public News(){

    }
    public News(String news_title,String desc,String path){
        this.news_title=news_title;
        this.desc=desc;
       // this.newsTime=newsTime;
        this.path=path;
    }
    public String getNews_title(){
        return news_title;
    }
    public void setNews_title(String news_title){
        this.news_title=news_title;
    }
    public String getPath(){
        return path;
    }
    public void setPath(String path){
        this.path=path;
    }
    public String getDesc(){
        return desc;
    }
    public void setDesc(String desc){
        this.desc=desc;
    }
}
