package com.example.wordslist.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;
import android.app.FragmentManager;

import android.app.FragmentTransaction;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import com.example.wordslist.Fragments.SelectWords;
import com.example.wordslist.Fragments.Unknownwords;
import com.example.wordslist.Fragments.Wordslist;
import com.example.wordslist.R;


public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    private List<Fragment> list;
    private ViewPager viewPager;

    private Wordslist wordLists;//展示单词列表的fragment
    private SelectWords selectWords;//展示单词查询的fragment
    private Unknownwords unknownWords;//展示生词本的fragment
    private View wordLists_Layout;//单词列表界面布局
    private View selectWords_Layout;//搜索单词界面布局
    private View unknownWords_Layout;//生词本界面布局
    private FragmentManager fragmentManager;//管理fragment


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
        fragmentManager=getFragmentManager();
        setTableSelection(0);
    }

    private void initView(){
        wordLists_Layout=findViewById(R.id.wordslist_layout);
        selectWords_Layout=findViewById(R.id.selectwords_layout);
        unknownWords_Layout=findViewById(R.id.unknownwords_layout);
        wordLists_Layout.setOnClickListener(this);
        selectWords_Layout.setOnClickListener(this);
        unknownWords_Layout.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.wordslist_layout:
                setTableSelection(0);
                //wordslist_text.setBackgroundColor(Color.BLUE);
                break;
            case R.id.selectwords_layout:
                setTableSelection(1);
                //selectwords_text.setBackgroundColor(Color.BLUE);
                break;
            case R.id.unknownwords_layout:
                setTableSelection(2);
                //unknownwords_text.setBackgroundColor(Color.BLUE);
                break;
            default:break;
        }

    }

    private void setTableSelection(int index){
        clearSelection();
        FragmentTransaction transaction=fragmentManager.beginTransaction();
        hideFragments(transaction);
        switch (index){
            case 0:
                wordLists_Layout.setBackgroundColor(0xff0000ff);
                selectWords_Layout.setBackgroundColor(0xffffffff);
                unknownWords_Layout.setBackgroundColor(0xffffffff);
                if(wordLists==null){
                    wordLists=new Wordslist();
                    transaction=fragmentManager.beginTransaction();
                    transaction.add(R.id.content, wordLists);
                }
                else{
                    transaction.show(wordLists);
                }
                break;
            case 1:
                selectWords_Layout.setBackgroundColor(0xff0000ff);
                wordLists_Layout.setBackgroundColor(0xffffffff);
                unknownWords_Layout.setBackgroundColor(0xffffffff);
                if(selectWords==null){
                    selectWords=new SelectWords();
                    transaction=fragmentManager.beginTransaction();
                    transaction.add(R.id.content, selectWords);
                }
                else{
                    transaction.show(selectWords);
                }
                break;
            case 2:
                unknownWords_Layout.setBackgroundColor(0xff0000ff);
                wordLists_Layout.setBackgroundColor(0xffffffff);
                selectWords_Layout.setBackgroundColor(0xffffffff);
                if(unknownWords==null){
                    unknownWords=new Unknownwords();
                    transaction=fragmentManager.beginTransaction();
                    transaction.add(R.id.content, unknownWords);
                }
                else{
                    transaction.show(unknownWords);
                }
                break;
            default:break;
        }
        transaction.commit();
    }

    private void hideFragments(FragmentTransaction transaction) {
        if (wordLists!=null) {
            transaction.hide(wordLists);
        }
        if (selectWords!= null) {
            transaction.hide(selectWords);
        }
        if (unknownWords!= null) {
            transaction.hide(unknownWords);
        }
    }

    private void clearSelection() {
        wordLists_Layout.setBackgroundColor(0xffffffff);
        selectWords_Layout.setBackgroundColor(0xffffffff);
        wordLists_Layout.setBackgroundColor(0xffffffff);
    }



    public class MyPagerChangeListener implements ViewPager.OnPageChangeListener {

        @Override
        public void onPageScrollStateChanged(int arg0) {
        }

        @Override
        public void onPageScrolled(int arg0, float arg1, int arg2) {
        }

        @Override
        public void onPageSelected(int arg0) {


        }

    }


    public boolean onOptionsItemSelected(MenuItem item){
        int id=item.getItemId();
        switch (id){
            case R.id.help:
                Toast.makeText(this,"help",Toast.LENGTH_LONG).show();
                break;
            case R.id.exit:
                MainActivity.this.finish();
        }
        return super.onOptionsItemSelected(item);
    }



}
