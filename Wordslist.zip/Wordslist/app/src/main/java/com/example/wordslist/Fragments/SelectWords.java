package com.example.wordslist.Fragments;

import android.app.FragmentManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import android.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ListView;


import com.example.wordslist.Activity.NewsActivity;
import com.example.wordslist.Beans.News;
import com.example.wordslist.R;

import android.view.Menu;
import android.webkit.WebView;
import android.widget.EditText;

import java.util.ArrayList;



/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link SelectWords.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link SelectWords#newInstance} factory method to
 * create an instance of this fragment.
 */
public class SelectWords extends Fragment implements View.OnClickListener{
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private EditText etWord;
    private WebView wvSearchResult;
    private Button Search;
    private FragmentManager fManager;
    private ArrayList<News> news;
    private ListView list_news;

    private OnFragmentInteractionListener mListener;

    public SelectWords() {
        // Required empty public constructor
    }





    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment SelectWords.
     */
    // TODO: Rename and change types and number of parameters
    public static SelectWords newInstance(String param1, String param2) {
        SelectWords fragment = new SelectWords();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(final LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View selectWords=inflater.inflate(R.layout.fragment_select_words, container, false);
        etWord = (EditText)selectWords.findViewById(R.id.etWord);
        wvSearchResult = (WebView)selectWords.findViewById(R.id.wvSearchResult);
        Search=(Button)selectWords.findViewById(R.id.btnSearch);
        Search.setOnClickListener(this);
        Button skip=(Button)selectWords.findViewById(R.id.btn_skip);
        /*Button jinshan=(Button)selectWords.findViewById(R.id.btn_jinshan);
        jinshan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent();
                intent.setClass(getActivity(), JSearchActivity.class);
                startActivity(intent);
            }
        });*/
        skip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent();
                intent.setClass(getActivity(), NewsActivity.class);
                startActivity(intent);
            }
        });
        //TextView textView=(TextView)selectWords.findViewById(R.id.textView3);
        return selectWords;
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    @Override
    public void onClick(View view) {
        String strURI = (etWord.getText().toString());
        strURI = strURI.trim();
        //如果查询内容为空提示
        if (strURI.length() == 0)
        {
            //Toast.makeText(MainActivity.this, "查询内容不能为空!", Toast.LENGTH_LONG)
            //  .show();
        }
        //否则则以参数的形式从http://dict.youdao.com/m取得数据，加载到WebView里.
        else
        {
            String strURL = "http://dict.youdao.com/m/search?keyfrom=dict.mindex&q="+ strURI;
            wvSearchResult.loadUrl(strURL);
        }

    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other com.example.wordslist.Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }

    //@Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        //getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    public void search(View view){


    }


}