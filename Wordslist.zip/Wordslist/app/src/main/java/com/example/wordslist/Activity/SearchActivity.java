package com.example.wordslist.Activity;

import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;

import com.example.wordslist.Beans.Words;
import com.example.wordslist.Database.OpenHelper;
import com.example.wordslist.Fragments.Unknownwords;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.ContextMenu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TableLayout;
import android.widget.TextView;

import com.example.wordslist.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SearchActivity extends AppCompatActivity {

    private ListView slist;
    private OpenHelper openHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        slist=(ListView)findViewById(R.id.slist);
        openHelper=new OpenHelper(this,"wordsdb",null,2);
        Intent intent=getIntent();
        ArrayList<Map<String, String>> arrayList=(ArrayList<Map<String, String>>)intent.getSerializableExtra("result");
        setWordsListView(arrayList);
        registerForContextMenu(slist);
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View view, ContextMenu.ContextMenuInfo menuInfo){
        super.onCreateContextMenu(menu,view,menuInfo);
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.contextmenu_slistview,menu);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item){
        switch (item.getItemId()){
            case R.id.action_add:
                AdapterView.AdapterContextMenuInfo info=(AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
                int q=(int) info.id;
                final View v1= slist.getChildAt(q);
               // final LinearLayout linearLayout = (LinearLayout)this.getLayoutInflater().inflate(R.layout.select_item, null);
                AlertDialog.Builder builder=new AlertDialog.Builder(SearchActivity.this);
                builder.setTitle("提示").setMessage("是否将单词添加到生词本");
                builder.setPositiveButton("是", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String strWord=((TextView)v1.findViewById(R.id.word)).getText().toString();
                        String strMeaning=((TextView)v1.findViewById(R.id.wordmeaning)).getText().toString();
                        String strSample=((TextView)v1.findViewById(R.id.wordsample)).getText().toString();

                        //既可以使用Sql语句插入，也可以使用使用insert方法插入
                        // InsertUserSql(strWord, strMeaning, strSample);
                        UInsert(strWord, strMeaning, strSample);
                        //Unknownwords unknownwords = new Unknownwords();
                        Intent intent = new Intent(SearchActivity.this,MainActivity.class);
                        intent.putExtra("id", 1);
                        startActivity(intent);
                        //unknownwords.setArguments(bundle);

                    }
                });
                builder.setNegativeButton("否", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                builder.show();
                break;
        }
        return true;
    }

    private void setWordsListView(ArrayList<Map<String,String>> items){
        SimpleAdapter adapter = new SimpleAdapter(SearchActivity.this,items,R.layout.select_item,new
                String[]{ "word","posAcceptation",
                "sent"},new int[]{R.id.word,R.id.wordmeaning,
                R.id.wordsample});//listitem
        slist.setAdapter(adapter);
    }

    private void UInsertUserSql(String strWord,String strMeaning,String strSample){
        String sql="insert into  UWords(word,posAcceptation,sample) values(?,?,?)";

        //Gets the data repository in write mode*/
        SQLiteDatabase db = openHelper.getWritableDatabase();
        db.execSQL(sql,new String[]{strWord,strMeaning,strSample});
    }

    private void UInsert(String strWord, String strMeaning, String strSample) {

        //Gets the data repository in write mode*/
        SQLiteDatabase db = openHelper.getWritableDatabase();

        // Create a new map of values, where column names are the keys
        ContentValues values = new ContentValues();
        values.put("word", strWord);
        values.put("posAcceptation", strMeaning);
        values.put("sample", strSample);

        // Insert the new row, returning the primary key value of the new row
        long newRowId;
        newRowId = db.insert(
                Words.Word.NEWTABLE_NAME,
                null,
                values);
    }

}
