package com.example.wordslist.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.wordslist.Beans.News;
import com.example.wordslist.R;

import java.util.List;

public class MyAdapter extends BaseAdapter {
    private List<News> mNews;
    private Context mContext;
    private View view;
    private ViewHolder viewHolder;

    public MyAdapter(List<News> mNews,Context mContext){
        this.mNews=mNews;
        this.mContext=mContext;
    }
    @Override
    public int getCount() {
        return mNews.size();
    }

    @Override
    public Object getItem(int position) {
        return mNews.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup viewGroup) {
        if (convertView == null) {
            view = LayoutInflater.from(mContext).inflate(R.layout.list_item,
                    null);
            viewHolder = new ViewHolder();
            viewHolder.newsTitle = (TextView) view
                    .findViewById(R.id.news_title);
            viewHolder.newsDesc = (TextView)view.findViewById(R.id.news_desc);
            //viewHolder.newsTime = (TextView)view.findViewById(R.id.news_time);
            view.setTag(viewHolder);
        } else {
            view = convertView;
            viewHolder = (ViewHolder) view.getTag();
        }
        viewHolder.newsTitle.setText(mNews.get(position).getNews_title());
        viewHolder.newsDesc.setText(mNews.get(position).getDesc());
       // viewHolder.newsTime.setText("来自 : "+newsList.get(position).getNewsTime());
        return view;
    }

    private class ViewHolder{
        TextView newsTitle;
        TextView newsDesc;
    }
}
