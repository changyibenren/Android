package com.example.wordslist.Database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import com.example.wordslist.Beans.Words;

public class OpenHelper extends SQLiteOpenHelper {

    private static final String CREATE_WORDS="CREATE TABLE "+Words.Word.TABLE_NAME+"("+
            Words.Word._ID+" INTEGER PRIMARY KEY AUTOINCREMENT,"+"isChinese text,word text,fy text,psE text,pronE text,psA text,pronA text,posAcceptation text,sent text)";
    private static final String DELETE_WORDS="DROP TABLE IF EXISTS "+Words.Word.TABLE_NAME;
    private static final String DELETE_UWORDS="DROP TABLE IF EXISTS "+Words.Word.NEWTABLE_NAME;
    private static final String CREATE_UWORDS="CREATE TABLE "+Words.Word.NEWTABLE_NAME+"("+
            Words.Word._ID+" INTEGER PRIMARY KEY AUTOINCREMENT,"+"word text,posAcceptation text,sample text)";
    private static final String DATABASE_NAME="wordsdb";
    private static final int DATABASE_VERSION=2;
    private Context mContext;

    public OpenHelper(Context context,String name,SQLiteOpenHelper factory,int version){
        super(context,DATABASE_NAME,null,DATABASE_VERSION);
        mContext=context;
    }


    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(CREATE_WORDS);
        sqLiteDatabase.execSQL(CREATE_UWORDS);
        Toast.makeText(mContext,"Created",Toast.LENGTH_LONG).show();
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL(DELETE_WORDS);
        sqLiteDatabase.execSQL(DELETE_UWORDS);
        onCreate(sqLiteDatabase);
    }
}
