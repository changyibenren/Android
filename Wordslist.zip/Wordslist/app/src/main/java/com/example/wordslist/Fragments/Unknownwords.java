package com.example.wordslist.Fragments;

import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;

import android.app.Fragment;

import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.wordslist.Activity.NewsActivity;
import com.example.wordslist.Activity.SearchActivity;
import com.example.wordslist.Beans.Words;
import com.example.wordslist.Database.OpenHelper;
import com.example.wordslist.R;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link Unknownwords.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link Unknownwords#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Unknownwords extends Fragment{
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private OnFragmentInteractionListener mListener;
    private ListView ulist;
    private OpenHelper openHelper;

    public Unknownwords() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment Unknownwords.
     */
    // TODO: Rename and change types and number of parameters
    public static Unknownwords newInstance(String param1, String param2) {
        Unknownwords fragment = new Unknownwords();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View unKnownWords=inflater.inflate(R.layout.fragment_unknownwords, container, false);
        //TextView textView=(TextView)unKnownWords.findViewById(R.id.textView);
        ulist=(ListView)unKnownWords.findViewById(R.id.uwords_list);
        openHelper=new OpenHelper(this.getActivity(),"wordsdb",null,2);
        ArrayList<Map<String,String>> items=getAll();
        setWordsListView(items);
        setHasOptionsMenu(true);
        registerForContextMenu(ulist);
        return unKnownWords;
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {

        inflater.inflate(R.menu.menu_main, menu);
        super.onCreateOptionsMenu(menu, inflater);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        int id=item.getItemId();
        switch (id){
            case R.id.action_search:
                SearchDialog();
                return true;
            case R.id.action_insert:
                InsertDialog();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void InsertUserSql(String strWord,String strMeaning,String strSample){
        String sql="insert into  UWords(word,posAcceptation,sample) values(?,?,?)";

        //Gets the data repository in write mode*/
        SQLiteDatabase db = openHelper.getWritableDatabase();
        db.execSQL(sql,new String[]{strWord,strMeaning,strSample});
    }

    private void Insert(String strWord, String strMeaning, String strSample) {

        //Gets the data repository in write mode*/
        SQLiteDatabase db = openHelper.getWritableDatabase();

        // Create a new map of values, where column names are the keys
        ContentValues values = new ContentValues();
        values.put("word", strWord);
        values.put("posAcceptation", strMeaning);
        values.put("sample", strSample);

        // Insert the new row, returning the primary key value of the new row
        long newRowId;
        newRowId = db.insert(
                Words.Word.NEWTABLE_NAME,
                null,
                values);
    }

    private void InsertDialog() {
        final TableLayout tableLayout = (TableLayout)this.getActivity().getLayoutInflater().inflate(R.layout.insert, null);
        new AlertDialog.Builder(this.getActivity())
                .setTitle("新增单词")//标题
                .setView(tableLayout)//设置视图
                //确定按钮及其动作
                .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        String strWord=((EditText)tableLayout.findViewById(R.id.txtWord)).getText().toString();
                        String strMeaning=((EditText)tableLayout.findViewById(R.id.txtMeaning)).getText().toString();
                        String strSample=((EditText)tableLayout.findViewById(R.id.txtSample)).getText().toString();

                        //既可以使用Sql语句插入，也可以使用使用insert方法插入
                        // InsertUserSql(strWord, strMeaning, strSample);
                        Insert(strWord, strMeaning, strSample);
                        ArrayList<Map<String, String>> items=getAll();
                        setWordsListView(items);
                    }
                })
                //取消按钮及其动作
                .setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                })
                .create()//创建对话框
                .show();//显示对话框
    }

    //使用Sql语句查找
    private ArrayList<Map<String, String>> SearchUseSql(String strWordSearch) {
        SQLiteDatabase db = openHelper.getReadableDatabase();

        String sql="select * from UWords where word like ? order by word desc";
        Cursor c=db.rawQuery(sql,new String[]{"%"+strWordSearch+"%"});

        return ConvertCursor2List(c);
    }

    //使用query方法查找
    private ArrayList<Map<String, String>> Search(String strWordSearch) {
        SQLiteDatabase db = openHelper.getReadableDatabase();

        String[] projection = {
                Words.Word._ID,
                Words.Word.COLUMN_NAME_WORD,
                Words.Word.COLUMN_NAME_MEANING,
                "sample"
        };

        String sortOrder =
                Words.Word.COLUMN_NAME_WORD + " DESC";

        String selection = Words.Word.COLUMN_NAME_WORD + " LIKE ?";
        String[] selectionArgs = {"%"+strWordSearch+"%"};

        Cursor c = db.query(
                Words.Word.NEWTABLE_NAME,  // The table to query
                projection,                              // The columns to return
                selection,                              // The columns for the WHERE clause
                selectionArgs,                            // The values for the WHERE clause
                null,                              // don't group the rows
                null,                              // don't filter by row groups
                sortOrder                              // The sort order
        );

        return ConvertCursor2List(c);
    }

    //查询对话框
    private void SearchDialog() {
        final TableLayout tableLayout = (TableLayout)this.getActivity().getLayoutInflater().inflate(R.layout.searchterm, null);
        new AlertDialog.Builder(this.getActivity())
                .setTitle("查找单词")//标题
                .setView(tableLayout)//设置视图
                //确定按钮及其动作
                .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        String txtSearchWord=((EditText)tableLayout.findViewById(R.id.txtSearchWord)).getText().toString();

                        ArrayList<Map<String, String>> items=null;
                        //既可以使用Sql语句查询，也可以使用方法查询
                        items=SearchUseSql(txtSearchWord);

                        if(items.size()>0) {
                            Bundle bundle=new Bundle();
                            bundle.putSerializable("result",items);
                            Intent intent=new Intent(getActivity(), SearchActivity.class);
                            intent.putExtras(bundle);
                            startActivity(intent);
                        }else
                            Toast.makeText(getActivity(),"没有找到", Toast.LENGTH_LONG).show();
                    }
                })
                //取消按钮及其动作
                .setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                })
                .create()//创建对话框
                .show();//显示对话框
    }

    private ArrayList<Map<String,String>> ConvertCursor2List(Cursor cursor){
        ArrayList<Map<String,String>> arrayList=new ArrayList<Map<String,String>>();
        while(cursor.moveToNext()) {
            Map<String, String> map = new HashMap<String, String>();
            map.put("word", cursor.getString(1));
            map.put("posAcceptation", cursor.getString(2));
            map.put("sample", cursor.getString(3));
            arrayList.add(map);
        }
        return arrayList;
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo){
        super.onCreateContextMenu(menu, v, menuInfo);
        menu.add(Menu.NONE, 111, Menu.NONE, "delete");
        menu.add(Menu.NONE, 222, Menu.NONE, "update");
    }


    @Override
    public boolean onContextItemSelected(MenuItem item) {
        TextView id = null;
        TextView word = null;
        TextView meaning = null;
        TextView sample = null;
        AdapterView.AdapterContextMenuInfo info = null;
        View itemView = null;
        switch (item.getItemId()) {
            case 111:
                info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
                itemView = info.targetView;
                id = (TextView) itemView.findViewById(R.id.uId);
                if (id != null) {
                    String strId = id.getText().toString();
                    DeleteDialog(strId);
                }
                break;
            case 222:
                info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
                itemView = info.targetView;
                id = (TextView) itemView.findViewById(R.id.uId);
                word = (TextView) itemView.findViewById(R.id.uWord);
                meaning = (TextView) itemView.findViewById(R.id.uMeaning);
                sample = (TextView) itemView.findViewById(R.id.uSample);
                if (id != null && word != null && meaning != null && sample != null) {
                    String strId = id.getText().toString();
                    String strWord = word.getText().toString();
                    String strMeaning = meaning.getText().toString();
                    String strSample = sample.getText().toString();
                    UpdateDialog(strId, strWord, strMeaning, strSample);
                }
                break;
        }
        return true;
    }

    //使用Sql语句更新单词
    private void UpdateUseSql(String strId,String strWord, String strMeaning, String strSample) {
        SQLiteDatabase db = openHelper.getReadableDatabase();
        String sql="update UWords set word=?,posAcceptation=?,sample=? where _id=?";
        db.execSQL(sql, new String[]{strWord, strMeaning, strSample,strId});
    }

    //使用方法更新
    private void Update(String strId,String strWord, String strMeaning, String strSample) {
        SQLiteDatabase db = openHelper.getReadableDatabase();


        // New value for one column
        ContentValues values = new ContentValues();
        values.put(Words.Word.COLUMN_NAME_WORD, strWord);
        values.put(Words.Word.COLUMN_NAME_MEANING, strMeaning);
        values.put("sample", strSample);

        String selection = Words.Word._ID + " = ?";
        String[] selectionArgs = {strId};

        int count = db.update(
                Words.Word.NEWTABLE_NAME,
                values,
                selection,
                selectionArgs);
    }

    //修改对话框
    private void UpdateDialog(final String strId, final String strWord, final String strMeaning, final String strSample) {
        final TableLayout tableLayout = (TableLayout)this.getActivity().getLayoutInflater().inflate(R.layout.insert, null);
        ((EditText)tableLayout.findViewById(R.id.txtWord)).setText(strWord);
        ((EditText)tableLayout.findViewById(R.id.txtMeaning)).setText(strMeaning);
        ((EditText)tableLayout.findViewById(R.id.txtSample)).setText(strSample);
        new AlertDialog.Builder(this.getActivity())
                .setTitle("修改单词")//标题
                .setView(tableLayout)//设置视图
                //确定按钮及其动作
                .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        String strNewWord = ((EditText) tableLayout.findViewById(R.id.txtWord)).getText().toString();
                        String strNewMeaning = ((EditText) tableLayout.findViewById(R.id.txtMeaning)).getText().toString();
                        String strNewSample = ((EditText) tableLayout.findViewById(R.id.txtSample)).getText().toString();

                        //既可以使用Sql语句更新，也可以使用使用update方法更新
                        UpdateUseSql(strId, strNewWord, strNewMeaning, strNewSample);
                        //  Update(strId, strNewWord, strNewMeaning, strNewSample);
                        setWordsListView(getAll());
                    }
                })
                //取消按钮及其动作
                .setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                })
                .create()//创建对话框
                .show();//显示对话框
    }

    private void DeleteUseSql(String strId) {
        String sql="delete from UWords where _id='"+strId+"'";

        //Gets the data repository in write mode*/
        SQLiteDatabase db = openHelper.getReadableDatabase();
        db.execSQL(sql);
    }

    private void Delete(String strId) {
        SQLiteDatabase db = openHelper.getReadableDatabase();
        // 定义where子句
        String selection = Words.Word._ID + " = ?";

        // 指定占位符对应的实际参数
        String[] selectionArgs = {strId};

        // Issue SQL statement.
        db.delete(Words.Word.NEWTABLE_NAME, selection, selectionArgs);
    }

    private void DeleteDialog(final String strId){
        new AlertDialog.Builder(this.getActivity()).setTitle("删除单词").setMessage("是否真的删除单词?").setPositiveButton("确定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                //既可以使用Sql语句删除，也可以使用使用delete方法删除
                DeleteUseSql(strId);
                //Delete(strId);
                setWordsListView(getAll());
            }
        }).setNegativeButton("取消", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        }).create().show();
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other com.example.wordslist.Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }

    private ArrayList<Map<String, String>> getAll() {
        ArrayList<Map<String, String>> list = new ArrayList<>();
        SQLiteDatabase db = openHelper.getReadableDatabase();
        Cursor c = db.query("UWords", null, null, null, null, null, null);
        int columns = c.getColumnCount();
        while(c.moveToNext()){
            Map<String, String> map = new HashMap<String, String>();
            for (int i = 0; i < columns; i++) {
                String word1 = c.getColumnName(i);
                String value1 = c.getString(c.getColumnIndex(word1));
                //System.out.println(value1);
                map.put(word1, value1);
            }
            list.add(map);
        }
       // Collections.sort(list);
        return list;
    }

    private void setWordsListView(ArrayList<Map<String,String>> items){
        SimpleAdapter adapter = new SimpleAdapter(this.getActivity(),items,R.layout.uword_item,new
                String[]{ Words.Word._ID,"word","posAcceptation",
                "sample"},new int[]{R.id.uId,R.id.uWord,R.id.uMeaning,
                R.id.uSample});//listitem
        ulist.setAdapter(adapter);
    }



}
