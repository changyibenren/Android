package com.example.wordslist.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import com.example.wordslist.Adapter.MyAdapter;
import com.example.wordslist.Beans.News;
import com.example.wordslist.R;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import java.util.ArrayList;
import java.util.List;

public class NewsActivity extends AppCompatActivity {

    //private TextView txt_title;
    private List<News> newsList;
    private ListView listView;
    private Handler handler;
    private MyAdapter myAdapter;
    //public static final String GET_NEWS_URL="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news);
        listView=(ListView)findViewById(R.id.list_news);
        newsList = new ArrayList<>();
        getNews();
        handler = new Handler(){
            @Override
            public void handleMessage(Message msg) {
                if(msg.what == 1){
                    myAdapter = new MyAdapter(newsList,NewsActivity.this);
                    listView.setAdapter(myAdapter);
                    listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                            News n = newsList.get(position);
                            Intent intent = new Intent(NewsActivity.this,NewsContentActivity.class);
                            intent.putExtra("news_url",n.getPath());
                            startActivity(intent);
                        }
                    });
                }
            }
        };
    }


    private void getNews(){
        new Thread(new Runnable() {
            @Override
            public void run() {
                try{
                    https://language.chinadaily.com.cn/news_bilingual/page_4.html
                    //获取20页的数据，网址格式为：https://voice.hupu.com/nba/第几页
                    for(int i = 1;i<=2;i++) {
                        Document doc = Jsoup.connect("https://language.chinadaily.com.cn/news_bilingual/page_"+String.valueOf(i)+".html").get();
                        Elements titleLinks = doc.select("div[class=gy_box_txt]");    //解析来获取每条新闻的标题与简介
                        Elements uriLinks = doc.select("p[class=gy_box_txt2]");//解析来获取每条新闻的链接地址
                        //Elements timeLinks = doc.select("div.otherInfo");   //解析来获取每条新闻的时间与来源

                        //for循环遍历获取到每条新闻的四个数据并封装到News实体类中
                        for(int j = 0;j < titleLinks.size();j++){
                            String title = titleLinks.get(j).select("p[class=gy_box_txt2]").text();
                            String uri = uriLinks.get(j).select("a").attr("href");
                           //System.out.println(uri);
                            //String uri = null;
                            //uri="https"+uri;
                            String desc = titleLinks.get(j).select("p[class=gy_box_txt3]").text();
                            // String time = timeLinks.get(j).select("span.other-left").select("a").text();
                            News n = new News(title,desc,uri);
                            newsList.add(n);
                        }
                    }
                    Message msg = new Message();
                    msg.what = 1;
                    handler.sendMessage(msg);

                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        }).start();             }


}
