package com.example.player;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;

public class MusicActivity extends AppCompatActivity implements View.OnClickListener{
    int flag=1;//设置标志，点击开始/暂停按钮使用
    private Button btn_start,btn_last,btn_next;
    private TextView textView_now,textView_total;
    private SeekBar MusicseekBar;
    private MusicService musicService = new MusicService();
    private Handler handler;// 处理改变进度条事件
    int UPDATE = 0x101;
    private boolean autoChange, manulChange;// 判断是进度条是自动改变还是手动改变
    private boolean isPause;// 判断是从暂停中恢复还是重新播放
    String information;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_music);
        btn_last = (Button) findViewById(R.id.btn_last);
        btn_start = (Button) findViewById(R.id.btn_start);
        btn_next = (Button) findViewById(R.id.btn_next);
        MusicseekBar=(SeekBar)findViewById(R.id.video_seekBar);
        textView_now=(TextView)findViewById(R.id.video_now_time);
        textView_total=(TextView)findViewById(R.id.video_total_time);
        btn_start.setOnClickListener(this);
        btn_next.setOnClickListener(this);
        btn_last.setOnClickListener(this);
        MusicseekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if(fromUser){
                    musicService.player.seekTo(progress);
                    MusicseekBar.setProgress(progress);
                }

                //9 updateTime(textView_now,progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                int progress = MusicseekBar.getProgress();
                Log.i("TAG:", "" + progress + "");
                int musicMax = musicService.player.getDuration();
                int seekBarMax = seekBar.getMax();
                musicService.player.seekTo(musicMax * progress / seekBarMax);
                autoChange = true;
                manulChange = false;
            }
        });
        //Thread thread=new Thread(this);
        handler = new Handler() {
            @Override
            public void handleMessage(Message msg) {
                super.handleMessage(msg);
                //更新UI
                int mMax = musicService.player.getDuration();//最大秒数
                if (msg.what == UPDATE) {
                    try {
                        //seekBar.setProgress(msg.arg1);
                        // information=setPlayInfo(msg.arg2 / 1000, mMax / 1000);
                        //  textView.setText(information);
                        // System.out.println(textView.getText());
                        int position = musicService.player.getCurrentPosition();
                        int totalduration = musicService.player.getDuration();

                        MusicseekBar.setMax(totalduration);
                        MusicseekBar.setProgress(position);

                        updateTime(textView_now,position);
                        updateTime(textView_total,totalduration);
                        //textView_now.setText();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } else {
                    MusicseekBar.setProgress(0);
                    // textView.setText("播放已经停止");
                }
            }
        };
    }

    Runner runner=new Runner();
    Thread t = new Thread(runner);
    public class Runner implements Runnable{
        @Override
        public void run() {
            int position, mMax, sMax;
            while (!Thread.currentThread().isInterrupted()) {
                if (musicService.player != null && musicService.player.isPlaying()) {
                    position = musicService.getCurrentProgress();//得到当前歌曲播放进度(秒)
                    System.out.println(position);
                    mMax = musicService.player.getDuration();//最大秒数
                    sMax = MusicseekBar.getMax();//seekBar最大值，算百分比
                    Message m = handler.obtainMessage();//获取一个Message
                    m.arg1 = position * sMax / mMax;//seekBar进度条的百分比
                    m.arg2 = position;
                    m.what = UPDATE;
                    handler.sendMessage(m);
                    //  handler.sendEmptyMessage(UPDATE);
                    try {
                        Thread.sleep(1000);// 每间隔1秒发送一次更新消息
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }

    private void updateTime(TextView textView,int millisecond){
        int second = millisecond/1000;
        int hh = second / 3600;
        int mm = second % 3600 / 60;
        int ss = second % 60;

        String str = null;
        if(hh!=0){
            str = String.format("%02d:%02d:%02d",hh,mm,ss);
        }else {
            str = String.format("%02d:%02d",mm,ss);
        }

        textView_now.setText(str);

    }


    //设置当前播放信息
    private String setPlayInfo(int position, int max) {
        String info = "正在播放:  " + musicService.songName + "\t\t";
        int pMinutes = 0;
        while (position >= 60) {
            pMinutes++;
            position -= 60;
        }
        String now = (pMinutes < 10 ? "0" + pMinutes : pMinutes) + ":"
                + (position < 10 ? "0" + position : position);

        int mMinutes = 0;
        while (max >= 60) {
            mMinutes++;
            max -= 60;
        }
        String all = (mMinutes < 10 ? "0" + mMinutes : mMinutes) + ":"
                + (max < 10 ? "0" + max : max);

        return info + now + " / " + all;
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btn_start:
                Intent i=getIntent();
                int position=i.getIntExtra("position",0);
                musicService.songNum=position;
                try{
                    if(flag==1){
                        musicService.play();
                        flag++;
                    }else{
                        if(!musicService.player.isPlaying()){
                            musicService.goPlay();
                        }else if(musicService.player.isPlaying()){
                            musicService.pause();
                        }
                    }
                } catch (Exception e) {
                    Log.i("LAT", "开始异常！");
                }
                break;
            case R.id.btn_last:
                try{
                    musicService.last();
                }catch (Exception exception){
                    Log.i("LAT","上一曲异常！");
                }
                break;
            case R.id.btn_next:
                try{
                    musicService.next();
                }catch (Exception exception){
                    Log.i("LAT","下一曲异常！");
                }
                break;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_music, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement


        return super.onOptionsItemSelected(item);
    }

}
