package com.example.player;

import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Environment;
import android.util.Log;
import android.widget.Toast;

import com.example.player.Filter.MusicFilter;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MusicService {
    private static final File PATH = Environment.getExternalStorageDirectory();// 获取SD卡总目录。
    public List<String> musicList;// 存放找到的所有mp3的绝对路径。
    public MediaPlayer player; // 定义多媒体对象
    public int songNum; // 当前播放的歌曲在List中的下标,flag为标志
    public String songName; // 当前播放的歌曲名
    // 记录的暂停时的播放位置
    private int pausePosition;
    // 当前播放的歌曲的索引
    private int currentMusicIndex;
    private int j=0;//j表示被添加歌曲在mlist中的下标
    public MusicService(){
        super();
        player=new MediaPlayer();
        musicList=new ArrayList<String>();
        try{
            File MUSIC_PATH=new File(PATH,"Pictures/");
           // System.out.println(MUSIC_PATH);
            if (MUSIC_PATH.listFiles(new MusicFilter()).length > 0) {
                for (File file : MUSIC_PATH.listFiles(new MusicFilter())) {
                    musicList.add(file.getAbsolutePath());
                }
            }
        }catch (Exception e){
            Log.i("TAG","读取文件异常");
        }
    }

    public void setMusicName(String source){
        File file=new File(source);
        String name=file.getName();
        int index=source.lastIndexOf(".");
        //songName=source.substring(0,index);
        //int end=name.length();
        songName=name;
       // System.out.println(songName);
    }

    public void play() {
        try {
            player.reset(); //重置多媒体
            String dataSource = musicList.get(songNum);//得到当前播放音乐的路径
     //       System.out.println(dataSource);
            //final int i=songNum;//保存当前歌曲的编号
            setMusicName(dataSource);//截取歌名
            // 指定参数为音频文件
            player.setAudioStreamType(AudioManager.STREAM_MUSIC);
            player.setDataSource(dataSource);//为多媒体对象设置播放路径
            player.prepare();//准备播放
            player.start();//开始播放
            //setOnCompletionListener 当当前多媒体对象播放完成时发生的事件
            player.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                public void onCompletion(MediaPlayer arg0) {
                    play();//如果当前歌曲播放完毕,循环播放.
                }
            });

        } catch (Exception e) {
            Log.v("MusicService", e.getMessage());
        }
    }

    //继续播放
    public void goPlay(){
        int position = getCurrentProgress();
        player.seekTo(position);//设置当前MediaPlayer的播放位置，单位是毫秒。
        try {
            player.prepare();//  同步的方式装载流媒体文件。
        } catch (Exception e) {
            e.printStackTrace();
        }
        player.start();
    }
    // 获取当前进度
    public int getCurrentProgress() {
        if (player != null & player.isPlaying()) {
            return player.getCurrentPosition();
        } else if (player != null & (!player.isPlaying())) {
            return player.getCurrentPosition();
        }
        return 0;
    }

    public void next() {
        songNum = songNum == musicList.size() - 1 ? 0 : songNum + 1;
        play();
    }

    public void last() {
        songNum = songNum == 0 ? musicList.size() - 1 : songNum - 1;
        play();
    }
    // 暂停播放
    public void pause() {
        if (player != null && player.isPlaying()){
            player.pause();
        }
    }

    public void stop() {
        if (player != null && player.isPlaying()) {
            player.stop();
            player.reset();
        }
    }

    //随机播放方法
    public void random() {
        currentMusicIndex = new Random().nextInt(musicList.size());
        pausePosition = 0;
        try {
            player.reset(); //重置多媒体
            String dataSource = musicList.get(currentMusicIndex);//得到当前播放音乐的路径
            setMusicName(dataSource);//截取歌名
            // 指定参数为音频文件
            player.setAudioStreamType(AudioManager.STREAM_MUSIC);
            player.setDataSource(dataSource);//为多媒体对象设置播放路径
            player.prepare();//准备播放
            player.start();//开始播放
            //setOnCompletionListener 当当前多媒体对象播放完成时发生的事件
            player.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                public void onCompletion(MediaPlayer arg0) {
                    //musicList.remove(currentMusicIndex);
                    random();
                }
            });

        } catch (Exception e) {
            Log.v("MusicService", e.getMessage());
        }

    }

    //列表循环
    public void sequence() {
        songNum=0;
        if (songNum >= musicList.size()) {
            songNum = 0;
        }
        pausePosition = 0;
        for(int i=0;i<musicList.size();i++){
            play();
            songNum++;
        }
        songNum=0;
    }

    public String getPath(int position){
        return musicList.get(position);
    }

    public void add(int position){
        File MUSIC_PATH=new File("/storage/emulated/legacy/Music/");
        List<String> mList=new ArrayList<String>();
        if (MUSIC_PATH.listFiles(new MusicFilter()).length > 0) {

            for (File file : MUSIC_PATH.listFiles(new MusicFilter())) {
               // int length=musicList.size();
                mList.add(file.getAbsolutePath());
               // musicList.add(file.getAbsolutePath());
            }
        }
        musicList.add(position,mList.get(j++));
    }


}
