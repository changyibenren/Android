package com.example.player;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;

import com.example.player.Adapter.GeneralAdapter;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;


import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import android.os.Environment;
import android.view.ContextMenu;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity{



    private ListView listView;
    private MusicService musicService=new MusicService();



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setListViewAdapter();
        registerForContextMenu(listView);
       // listView.setOnItemClickListener(this);
        ActionBar actionBar=getSupportActionBar();
        //listView.setOnItemSelectedListener(this);
        //ArrayAdapter<String> adapter = new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_list_item_1,data);
        //listView=findViewById(R.id.listview);
       // listView.setAdapter(adapter);


    }






    private void setListViewAdapter(){
        String[] str = new String[musicService.musicList.size()];
        List<String> list=new ArrayList<String>();
        int i = 0;
        for (String path : musicService.musicList) {
            File file = new File(path);
            str[i++] = file.getName();
        }
       // musicService.musicList.clear();
        for(i=0;i<str.length;i++){
           list.add(str[i]);
        }
       // ArrayAdapter adapter = new ArrayAdapter(this, R.layout.list_item,
                //str);
        GeneralAdapter adapter = new GeneralAdapter(this,R.layout.list_item,
                list);
        //adapter.getView();
        listView = (ListView) findViewById(R.id.listview);
        listView.setAdapter(adapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        switch (id){
            case R.id.random_play:
                musicService.random();
                break;
            case R.id.line_play:
                musicService.sequence();
                break;
            case R.id.stop_random:
                musicService.stop();
            case R.id.stop_line:
                musicService.stop();
        }

        return super.onOptionsItemSelected(item);
    }







}
