package com.example.player.Adapter;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.player.Filter.MusicFilter;
import com.example.player.MainActivity;
import com.example.player.MusicActivity;
import com.example.player.MusicService;
import com.example.player.R;

import java.io.File;
import java.sql.Array;
import java.util.ArrayList;
import java.util.List;

public class GeneralAdapter extends ArrayAdapter{
    private LayoutInflater mInflater;
    List<String> datas;
    private Context context;
    private TextView textView;
    private Button button;
    private Button button1;
    private int resource;
    private MusicService musicService=new MusicService();
    private int j=0;




    public GeneralAdapter(Context context,int resource,List<String> datas){
        super(context, resource, datas);
        this.context = context;
        this.resource = resource;
        this.datas = datas;
    }

    public void additem(int position){
        File MUSIC_PATH=new File("/storage/emulated/legacy/Music/");
        List<String> musicList=new ArrayList<String>();
        int i=0;
        musicService.add(position);
        if (MUSIC_PATH.listFiles(new MusicFilter()).length > 0) {

            for (File file : MUSIC_PATH.listFiles(new MusicFilter())) {
                musicList.add(file.getAbsolutePath());
            }

        }
        String[] str = new String[musicList.size()];

        for (String path : musicList) {

            File file = new File(path);

            str[i++] = file.getName();

        }

        datas.add(position,str[j++]);
        this.notifyDataSetChanged();
    }

    public void deleteitem(int position){
        File file=new File(musicService.getPath(position));
        file.delete();
        musicService.musicList.remove(position);
        datas.remove(position);
        this.notifyDataSetChanged();
    }


    @Override
    public int getCount() {
        return datas.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        mInflater=LayoutInflater.from(context);
        convertView=mInflater.inflate(resource,null);
        textView=(TextView)convertView.findViewById(R.id.text);
        button=(Button)convertView.findViewById(R.id.btn_delete);
        button1=(Button)convertView.findViewById(R.id.btn_add);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                additem(position);
            }
        });
       // System.out.println(datas.get(position));
        textView.setText(datas.get(position));
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(context, MusicActivity.class);
                intent.putExtra("position",position);
                System.out.println(position);
                context.startActivity(intent);
            }
        });
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder=new AlertDialog.Builder(context);
                builder.setMessage("是否删除？").setTitle("提示");
                builder.setPositiveButton("是", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        deleteitem(position);
                    }
                });
                builder.setNegativeButton("否", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                builder.show();
            }
        }
        );
        return convertView;
    }


}
