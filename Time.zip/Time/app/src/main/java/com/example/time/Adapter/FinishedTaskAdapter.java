package com.example.time.Adapter;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.time.Bean.Task;
import com.example.time.DataBase.OpenHelper;
import com.example.time.R;
import com.example.time.TaskViewHolder;

import java.util.ArrayList;

public class FinishedTaskAdapter extends RecyclerView.Adapter<TaskViewHolder>  {
    private ArrayList<Task> finishedtasks = new ArrayList<>();
    private Context context;
    private OpenHelper openHelper;
    public int isclick=0;
    public int isDelete=-1;//用于传参，对数据库内容进行修改
    private int clickNumber=0;

    public FinishedTaskAdapter(){
    }

    public FinishedTaskAdapter(Context context,ArrayList<Task> finishedtasks){
        this.finishedtasks=finishedtasks;
        this.context=context;
        openHelper=new OpenHelper(context,"tasks.db",null,1);
    }

    public void setTasks(Task task) {
        // 现将原列表清空，再将传入的列表元素全部加入
        //this.tasks.clear();
        this.finishedtasks.add(task);

    }

    @Override
    public TaskViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.task_item, parent, false);
        return new TaskViewHolder(v);
    }

    @Override
    public void onBindViewHolder(final TaskViewHolder holder, final int position) {
        holder.swipeMenuLayout.setIos(false);//设置是否开启IOS阻塞式交互
        holder.swipeMenuLayout.setLeftSwipe(true);//true往左滑动,false为往右侧滑动
        holder.swipeMenuLayout.setSwipeEnable(true);//设置侧滑功能开关

        // 取对应位置的笔记对象
        final Task task = finishedtasks.get(position);
        // 设置对应ViewHolder对象中各视觉元素的值
        holder.task.setText(task.getContent());
        holder.task_date.setText(task.getDate());
        holder.task.setChecked(true);
        holder.task.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    holder.task.setChecked(true);
            }
        });
        holder.btn_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Toast.makeText(context,"删除",Toast.LENGTH_SHORT).show();
                // TodayFragment.DeleteDialog();
                // String sposition=String.valueOf(position);
                //isDelete=position;
                //TodayFragment.DeleteDialog(sposition);
                // TodayFragment.DeleteUseSql(position);
                // TodayFragment.task
                new AlertDialog.Builder(context).setTitle("删除任务").setMessage("确定删除任务?").setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        removeTask(position);
                    }
                }).setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                }).create().show();
            }
        });
    }
    public void addTask(int position,Task task) {
//      在list中添加数据，并通知条目加入一条
        finishedtasks.add(position, task);
        //添加动画
        notifyItemInserted(position);
    }

    public void add(Task task){
        addTask(finishedtasks.size(),task);
    }

    public void removeTask(int position) {
        finishedtasks.remove(position);
        //删除动画
        notifyItemRemoved(position);
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return finishedtasks.size();
    }

}
