package com.example.time.DataBase;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import com.example.time.Bean.Task;

public class OpenHelper extends SQLiteOpenHelper {
    private static final String CREATE_UNFINISHEDTASKS="CREATE TABLE "+ Task.Tasks.TABLE_NAME1+"("+
            Task.Tasks._ID+" INTEGER PRIMARY KEY AUTOINCREMENT,"+"content text,date text,priority int,state int)";
    private static final String DELETE_UNFINISHEDTASKS="DROP TABLE IF EXISTS "+ Task.Tasks.TABLE_NAME1;
    private static final String CREATE_FINISHEDTASKS="CREATE TABLE "+ Task.Tasks.TABLE_NAME2+"("+
            Task.Tasks._ID+" INTEGER PRIMARY KEY AUTOINCREMENT,"+"content text,date text,priority int,state int)";
    private static final String DELETE_FINISHEDTASKS="DROP TABLE IF EXISTS "+ Task.Tasks.TABLE_NAME2;
    private static final String CREATE_DELETEDTASKS="CREATE TABLE "+ Task.Tasks.TABLE_NAME3+"("+
            Task.Tasks._ID+" INTEGER PRIMARY KEY AUTOINCREMENT,"+"content text,date text,priority int,state int)";
    private static final String DELETE_DELECTEDTASKS="DROP TABLE IF EXISTS "+ Task.Tasks.TABLE_NAME3;
    private static final String DATABASE_NAME="tasks.db";
    private static final int DATABASE_VERSION=1;
    private Context mContext;

    public OpenHelper(Context context,String name,SQLiteOpenHelper factory,int version){
        super(context,DATABASE_NAME,null,DATABASE_VERSION);
        mContext=context;
    }
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(CREATE_UNFINISHEDTASKS);
        sqLiteDatabase.execSQL(CREATE_FINISHEDTASKS);
        sqLiteDatabase.execSQL(CREATE_DELETEDTASKS);
        Toast.makeText(mContext,"Created",Toast.LENGTH_LONG).show();
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {
        sqLiteDatabase.execSQL(DELETE_UNFINISHEDTASKS);
        sqLiteDatabase.execSQL(DELETE_FINISHEDTASKS);
        sqLiteDatabase.execSQL(DELETE_DELECTEDTASKS);
        onCreate(sqLiteDatabase);
    }
}
