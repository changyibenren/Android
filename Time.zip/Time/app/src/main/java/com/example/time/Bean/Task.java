package com.example.time.Bean;

import android.provider.BaseColumns;

public class Task implements Comparable<Task>{
    private String content;
    private String date;
    private int priority;
    private int state=0;
    public Task(){}
    public Task(String content, String date, int priority, int state){
        this.content=content;
        this.date=date;
        this.priority=priority;
        this.state = state;
    }
    public String getContent(){
        return this.content;
    }
    public void setContent(String content){
        this.content=content;
    }
    public String getDate(){
        return this.date;
    }
    public void setDate(String date){
        this.date=date;
    }
    public int getPriority(){
        return this.priority;
    }
    public void setPriority(int priority){
        this.priority=priority;
    }
    public int getState(){
        return this.state;
    }
    public void setState(int state){
        this.state=state;
    }

    @Override
    public int compareTo(Task task) {
        return task.priority-this.priority;
    }

    public static abstract class Tasks implements BaseColumns{
        public static final String TABLE_NAME1="UnFinishedTasks";
        public static final String TABLE_NAME2="FinishedTasks";
        public static final String TABLE_NAME3="DeletedTasks";
        public static final String COLUMN_NAME_CONTENT="content";
        public static final String COLUMN_NAME_DATE="date";
        public static final String COLUMN_NAME_Priority="priority";
        public static final String COLUMN_NAME_STATE="state";

    }
}
