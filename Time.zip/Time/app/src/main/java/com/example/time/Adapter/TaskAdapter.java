package com.example.time.Adapter;

import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;


import androidx.recyclerview.widget.RecyclerView;

import com.example.time.Bean.Task;
import com.example.time.DataBase.OpenHelper;
import com.example.time.Fragment.TodayFragment;
import com.example.time.R;
import com.example.time.TaskViewHolder;


import java.util.ArrayList;


public class TaskAdapter extends RecyclerView.Adapter<TaskViewHolder> {


    //private static ArrayList<Task> finishedTasks = new ArrayList<>();
   // private boolean isToday= DateUtils.isToday()
    private Context context;
    public int isclick=0;
    public int isDelete=-1;//用于传参，对数据库内容进行修改
    private int clickNumber=0;
    private static OpenHelper openHelper;
    private ArrayList<Task> tasks = new ArrayList<>();
    private static int FinishedNumber;
    //private static ArrayList<Task> tasks = new ArrayList<>();使用静态变量，导致数据覆盖



    public TaskAdapter(){
    }

    public TaskAdapter(Context context,ArrayList<Task> tasks){
        this.tasks=tasks;
        this.context=context;
        openHelper=new OpenHelper(context,"tasks.db",null,1);
       // for (int i = 0; i < tasks.size(); ++i) {
          //  Log.i("debugging", this.tasks.get(i).getContent());
      //  }
    }

    public void setTasks(Task task) {
        // 现将原列表清空，再将传入的列表元素全部加入
        //this.tasks.clear();
         this.tasks.add(task);

    }

    @Override
    public TaskViewHolder onCreateViewHolder( ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.task_item, parent, false);
        return new TaskViewHolder(v);
        //return taskViewHolder;
    }

    public int getFinishedNumber(){
        return FinishedNumber;
    }

    @Override
    public void onBindViewHolder(final TaskViewHolder holder, final int position) {
        holder.swipeMenuLayout.setIos(false);//设置是否开启IOS阻塞式交互
        holder.swipeMenuLayout.setLeftSwipe(true);//true往左滑动,false为往右侧滑动
        holder.swipeMenuLayout.setSwipeEnable(true);//设置侧滑功能开关


        // 取对应位置的笔记对象
        final Task task = tasks.get(position);
        // 设置对应ViewHolder对象中各视觉元素的值
        holder.task.setText(task.getContent());
        holder.task_date.setText(task.getDate());
       // holder.task.setChecked(true);
        holder.task.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clickNumber++;
       //         System.out.println(clickNumber);
                if(clickNumber%2!=0) {
                   // removeTask(position);
                   // InsertFinishedTasks(task);
                    holder.task.setChecked(true);
                    FinishedNumber++;
                    ChangeState(String.valueOf(position+1));
                   // task.setState(1);
                   // holder.task.setChecked(true);
                }
                else if(clickNumber%2==0){
                    holder.task.setChecked(false);
                }
            }
        });
        holder.btn_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Toast.makeText(context,"删除",Toast.LENGTH_SHORT).show();
               // TodayFragment.DeleteDialog();
               // String sposition=String.valueOf(position);
               //isDelete=position;
                //TodayFragment.DeleteDialog(sposition);
               // TodayFragment.DeleteUseSql(position);
               // TodayFragment.task
               // final AdapterView.AdapterContextMenuInfo info = null;
               // final View itemView = null;
                new AlertDialog.Builder(context).setTitle("删除任务").setMessage("确定删除任务?").setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        String strId = String.valueOf(position+1);
                        DeleteUseSql(strId);
                        removeTask(position);
                    }
                }).setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                }).create().show();
            }
        });
        holder.task.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                isclick=1;
                AlertDialog.Builder builder=new AlertDialog.Builder(context);
                LayoutInflater layoutInflater=LayoutInflater.from(context);
                final View view=layoutInflater.inflate(R.layout.edit,null);
                builder.setTitle("编辑").setView(view);
                builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String task_content=((EditText)view.findViewById(R.id.task_content)).getText().toString();
                        TextView task_date=(TextView) view.findViewById(R.id.task_date);
                        holder.task.setText(task_content);
                        task_date.setText(task.getDate());
                        task_date.setFocusable(false);
                        task_date.setEnabled(false);
                        task_date.setKeyListener(null);
                    }
                }).setNegativeButton("取消", new DialogInterface.OnClickListener(){
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                }).create().show();
                return true;
            }
        });

    }
    public void addTask(int position,Task task) {
//      在list中添加数据，并通知条目加入一条
        tasks.add(position, task);
        //添加动画
        notifyItemInserted(position);
    }

    public void add(Task task){
        addTask(tasks.size(),task);
    }

    public void removeTask(int position) {
        tasks.remove(position);
        //删除动画
        notifyItemRemoved(position);
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return tasks.size();
    }

    private void ChangeState(String strId){
        String sql="UPDATE UnFinishedTasks SET state = '1' WHERE _id ='"+strId+"'";
        SQLiteDatabase db = openHelper.getReadableDatabase();
        db.execSQL(sql);
    }



    public void DeleteUseSql(String strId) {
        String sql="delete from UnFinishedTasks where _id='"+strId+"'";
        //Gets the data repository in write mode*/
        SQLiteDatabase db = openHelper.getReadableDatabase();
        db.execSQL(sql);
    }






}
