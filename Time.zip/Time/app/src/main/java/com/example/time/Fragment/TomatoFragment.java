package com.example.time.Fragment;

import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.TimePicker;

import androidx.fragment.app.Fragment;

import com.example.time.R;

/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link TomatoFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link TomatoFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class TomatoFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private OnFragmentInteractionListener mListener;

    private TextView remaining_time;
    private CountDownTimer timer;
    private Button button_start;
    private boolean shortPress=false;
    private int minute=25;
    private int clickNumber=0;

    public TomatoFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment TomatoFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static TomatoFragment newInstance(String param1, String param2) {
        TomatoFragment fragment = new TomatoFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view=inflater.inflate(R.layout.fragment_tomato, container, false);
        remaining_time=view.findViewById(R.id.re_time);
        button_start=view.findViewById(R.id.start);
        remaining_time.setText(minute+":00");
        //remaining_time.setText(minute+":00");
        //remaining_time.setOnLongClickListener(new View.OnLongClickListener() {


       // });
        timer=new CountDownTimer(minute*60*1000,1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                //millisUntilFinished=(long)minute;
                remaining_time.setText(formatTime(millisUntilFinished));
                System.out.println(minute);
                //System.out.println(remaining_time.getText().toString());
            }

            @Override
            public void onFinish() {
                remaining_time.setText("00:00");
            }
        };
        button_start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clickNumber++;
                if(clickNumber%2!=0){
                    timerStart();
                }
                else if(clickNumber%2==0){
                    timerCancel();
                }

            }
        });

        // remaining_time.setText("sdsdsds");
        return view;
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }

    public String formatTime(long millisecond) {
        int minute;//分钟
        int second;//秒数
        minute = (int) ((millisecond / 1000) / 60);
        second = (int) ((millisecond / 1000) % 60);
        if (minute < 10) {
            if (second < 10) {
                return "0" + minute + ":" + "0" + second;
            } else {
                return "0" + minute + ":" + second;
            }
        }else {
            if (second < 10) {
                return minute + ":" + "0" + second;
            } else {
                return minute + ":" + second;
            }
        }
    }


    public void timerCancel(){
        timer.cancel();
    }

    public void timerStart(){
        timer.start();
    }




}