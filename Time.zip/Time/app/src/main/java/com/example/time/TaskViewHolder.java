package com.example.time;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.CheckedTextView;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.time.Bean.Task;
import com.example.time.View.SwipeMenuLayout;

public class TaskViewHolder extends RecyclerView.ViewHolder {
    public CheckedTextView task;
    public TextView task_date;
    public SwipeMenuLayout swipeMenuLayout;
    public Button btn_delete;
    public TaskViewHolder( View itemView) {
        super(itemView);
        task=itemView.findViewById(R.id.task);
        task_date=itemView.findViewById(R.id.task_date);
        swipeMenuLayout=itemView.findViewById(R.id.swipeMenuLayout);
        btn_delete=itemView.findViewById(R.id.btnDelete);
    }
}
