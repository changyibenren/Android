package com.example.time;

import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;

import com.example.time.Fragment.CollectFragment;
import com.example.time.Fragment.SetFragment;
import com.example.time.Fragment.TodayFragment;
import com.example.time.Fragment.TomatoFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

public class MainActivity extends AppCompatActivity implements CollectFragment.OnFragmentInteractionListener,SetFragment.OnFragmentInteractionListener,TodayFragment.OnFragmentInteractionListener,TomatoFragment.OnFragmentInteractionListener {

    private Fragment[] mFragments = new Fragment[4];
    private int mPreFragmentFlag=0;
    private SetFragment setFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        BottomNavigationView navView = findViewById(R.id.nav_view);
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(
                R.id.navigation_collectbox, R.id.navigation_today, R.id.navigation_tomato,R.id.navigation_set)
                .build();
        //NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
    //    NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
     //   NavigationUI.setupWithNavController(navView, navController);
        initFragment();
        navView.setItemIconTintList(null);
        navView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.navigation_collectbox:
                        showAndHideFragment(mFragments[0], mFragments[mPreFragmentFlag]);
                        mPreFragmentFlag = 0;
                        break;
                    case R.id.navigation_today:
                        showAndHideFragment(mFragments[1], mFragments[mPreFragmentFlag]);
                        mPreFragmentFlag = 1;
                        break;
                    case R.id.navigation_tomato:
                        showAndHideFragment(mFragments[2], mFragments[mPreFragmentFlag]);
                        mPreFragmentFlag = 2;
                        break;
                    case R.id.navigation_set:
                        showAndHideFragment(mFragments[3], mFragments[mPreFragmentFlag]);
                        mPreFragmentFlag = 3;
                        break;
                }
                return true;
            }
        });
    }

    private void initFragment() {

        //初始化fragment数组，按图标顺序
        mFragments[0] = new CollectFragment();
        mFragments[1] = new TodayFragment();
        mFragments[2] = new TomatoFragment();
        mFragments[3] = new SetFragment();
        initLoadFragment(R.id.main_layout, 0, mFragments);
    }
    // 参数一 是一个FrameLayout的ID，用来动态加载Fragment，
    private void initLoadFragment(int containerId, int showFragment, Fragment... fragments) {
        //获取到FragmentManager实例的同时去开启事物
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        for (int i = 0; i < fragments.length; i++) {
            //首先将Fragment添加到事务中
            transaction.add(containerId, fragments[i], fragments[i].getClass().getName());
            //默认展示 fragments[showFragment]
            //这里做首次Fragment的展示，如果不是指定的Fragment就先隐藏，需要的时候再显示出来
            if (i != showFragment)
                transaction.hide(fragments[i]);
        }
        //提交事物
        transaction.commitAllowingStateLoss();

    }

    //加载不同的Fragment
    private void showAndHideFragment(Fragment show, Fragment hide) {
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        if (show != hide)
            transaction.show(show).hide(hide).commitAllowingStateLoss();

    }

    @Override
    public void onFragmentInteraction(Uri uri) {

    }



}
