package com.example.time.Fragment;

import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;


import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.time.Adapter.FinishedTaskAdapter;
import com.example.time.Adapter.TaskAdapter;
import com.example.time.Bean.DateEntity;
import com.example.time.Bean.Task;
import com.example.time.DataBase.OpenHelper;
import com.example.time.R;
import com.example.time.View.DataView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.Collections;

/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link TodayFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link TodayFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class TodayFragment extends Fragment implements View.OnClickListener{
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private OnFragmentInteractionListener mListener;
    private DataView dataView;
    private FloatingActionButton button_add;
    private RecyclerView taskslist;
    private RecyclerView finishedtaskslist;
    private ArrayList<Task> tasks=new ArrayList<>();
    private ArrayList<Task> finishedTasks=new ArrayList<>();
    private TaskAdapter adapter = new TaskAdapter();
    private FinishedTaskAdapter finishedTaskAdapter = new FinishedTaskAdapter();
    private OpenHelper openHelper;
    //没有实例化会产生空指针
    private Task task;
    private int priority=0;


    public TodayFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment TodayFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static TodayFragment newInstance(String param1, String param2) {
        TodayFragment fragment = new TodayFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
       // args.putInt("data",tasks.size());
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View today=inflater.inflate(R.layout.fragment_today, container, false);
        openHelper=new OpenHelper(this.getContext(),"tasks.db",null,1);
        dataView = (DataView)today.findViewById(R.id.week);
        button_add=(FloatingActionButton)today.findViewById(R.id.floatingActionButton);
        button_add.setOnClickListener(this);
        tasks=getAll();
        adapter=new TaskAdapter(this.getContext(),tasks);
        finishedTasks=getFinishedAll();
        finishedTaskAdapter=new FinishedTaskAdapter(this.getContext(),finishedTasks);
        taskslist=(RecyclerView)today.findViewById(R.id.taskslist);
        finishedtaskslist=(RecyclerView)today.findViewById(R.id.finishedtaskslist);
        //finishedtaskslist.setAdapter(adapter);
        // 设定为垂直列表
        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false);
        taskslist.setLayoutManager(layoutManager);
//        finishedtaskslist.setLayoutManager(layoutManager);
        // 创建并设置适配器
        taskslist.setAdapter(adapter);
        finishedtaskslist.setAdapter(finishedTaskAdapter);
        //在函数外实例化获取不到context值

        dataView.setOnSelectListener(new DataView.OnSelectListener() {
            @Override
            public void onSelected(DateEntity date) {

            }
        });


        return today;
    }



    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.floatingActionButton:
                InsertDialog();
                break;
        }

    }

    private void InsertDialog() {
        final LinearLayout linearLayout = (LinearLayout)this.getActivity().getLayoutInflater().inflate(R.layout.insert, null);
        new AlertDialog.Builder(this.getContext())
                .setTitle("新建任务")//标题
                .setView(linearLayout)//设置视图
                //确定按钮及其动作
                .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        String task_date=((EditText)linearLayout.findViewById(R.id.task_date)).getText().toString();
                        String task_content=((EditText)linearLayout.findViewById(R.id.task_content)).getText().toString();
                        RadioGroup priority_collection=(RadioGroup)linearLayout.findViewById(R.id.priority_collection);
                        RadioButton priority_0=(RadioButton)linearLayout.findViewById(R.id.priority_0);
                        RadioButton priority_1=(RadioButton)linearLayout.findViewById(R.id.priority_1);
                        RadioButton priority_2=(RadioButton)linearLayout.findViewById(R.id.priority_2);
                        task=new Task();
                        // priority_0.AutoPostBack
                        task.setContent(task_content);
                        task.setDate(task_date);
                        task.setState(0);
                        // priority_0.setChecked();
                        onRadioButtonClicked(priority_0);
                        onRadioButtonClicked(priority_1);
                        onRadioButtonClicked(priority_2);
                        //既可以使用Sql语句插入，也可以使用使用insert方法插入
                        // InsertUserSql(strWord, strMeaning, strSample);
                        task.setPriority(priority);
                        Insert(task);
                        //ArrayList<Map<String, String>> items=getAll();
                        // setWordsListView(items);
                        //tasks.add(task);
                        adapter.add(task);
                        taskslist.setAdapter(adapter);
                    }
                })
                //取消按钮及其动作
                .setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                })
                .create()//创建对话框
                .show();//显示对话框
    }

    public void onRadioButtonClicked(View view) {
        RadioButton button = (RadioButton)view;
        boolean isChecked = button.isChecked();
        switch (view.getId()) {
            case R.id.priority_0:
                if (isChecked) {
                    priority=0;
                }
                break;
            case R.id.priority_1:
                if (isChecked) {
                    priority=1;
                }
                break;
            case R.id.priority_2:
                if (isChecked) {
                    priority=2;
                }
                break;
            default:
                break;
        }
    }




    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }

    public void InsertUserSql(Task task){
        String sql="insert into  UnFinishedTasks(content,date,priority,state) values(?,?,?,?)";

        //Gets the data repository in write mode*/
        SQLiteDatabase db = openHelper.getWritableDatabase();
        db.execSQL(sql,new Object[]{task.getContent(),task.getDate(),task.getPriority(),task.getState()});
    }

    public void Insert(Task task) {

        //Gets the data repository in write mode*/
        SQLiteDatabase db = openHelper.getWritableDatabase();

        // Create a new map of values, where column names are the keys
        ContentValues values = new ContentValues();
        values.put("content", task.getContent());
        values.put("date", task.getDate());
        values.put("priority", task.getPriority());
        values.put("state",task.getState());

        // Insert the new row, returning the primary key value of the new row
        long newRowId;
        newRowId = db.insert(
                Task.Tasks.TABLE_NAME1,
                null,
                values);
    }



    public ArrayList<Task> getAll() {
        ArrayList<Task> list = new ArrayList<>();
        SQLiteDatabase db = openHelper.getReadableDatabase();
        Cursor c = db.query("UnFinishedTasks", null, null, null, null, null, null);
        int colums = c.getColumnCount();
        while(c.moveToNext()) {
            Task task = new Task();
            // for (int i = 0; i < colums; i++) {
            String content = c.getString(c.getColumnIndex(c.getColumnName(1)));
            String date = c.getString(c.getColumnIndex(c.getColumnName(2)));
            task.setDate(date);
            task.setContent(content);
            list.add(task);
        }
        Collections.sort(list);
        return list;
    }

    public ArrayList<Task> getFinishedAll() {
        ArrayList<Task> list = new ArrayList<>();
        SQLiteDatabase db = openHelper.getReadableDatabase();
        Cursor c = db.query("FinishedTasks", null, null, null, null, null, null);
        int colums = c.getColumnCount();
        while(c.moveToNext()){
            Task task = new Task();
            // for (int i = 0; i < colums; i++) {

                String content = c.getString(c.getColumnIndex(c.getColumnName(1)));
                String date = c.getString(c.getColumnIndex(c.getColumnName(2)));
                task.setDate(date);
                task.setContent(content);
                list.add(task);

        }
        Collections.sort(list);
        return list;
    }



}
