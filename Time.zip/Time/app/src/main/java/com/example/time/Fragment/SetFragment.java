package com.example.time.Fragment;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import androidx.fragment.app.Fragment;

import com.example.time.Adapter.TaskAdapter;
import com.example.time.Bean.Task;
import com.example.time.DataBase.OpenHelper;
import com.example.time.R;
import com.github.mikephil.charting.animation.Easing;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.IAxisValueFormatter;
import com.github.mikephil.charting.formatter.IValueFormatter;
import com.github.mikephil.charting.interfaces.datasets.IBarDataSet;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.github.mikephil.charting.utils.ViewPortHandler;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link SetFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link SetFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class SetFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private OnFragmentInteractionListener mListener;
    private String[] types={"完成","未完成"};
    private TaskAdapter taskAdapter=new TaskAdapter();
    private int number;
    private EditText finished_number;
    private OpenHelper openHelper;
    private int total_number;
    private float f;
    private float[] changes=new float[2];
    private BarChart barChart;
    private PieChart pieChart;


    public SetFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment SetFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static SetFragment newInstance(String param1, String param2) {
        SetFragment fragment = new SetFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View set=inflater.inflate(R.layout.fragment_set, container, false);
        openHelper=new OpenHelper(getContext(),"tasks.db",null,1);
        finished_number=(EditText)set.findViewById(R.id.finished_number);
        finished_number.setText(2+"");
        String snumber=finished_number.getText().toString();
        if(snumber==null||snumber=="")
            number=0;
        else {
            number=Integer.parseInt(snumber);
        }
        total_number=getAll();
        f=number/total_number;
        changes[0]=number;
        changes[1]=total_number-number;
        barChart=(BarChart)set.findViewById(R.id.bar_chart);
        pieChart=(PieChart)set.findViewById(R.id.mPieChart);
        barChart.setScaleEnabled(false);
        barChart.setDoubleTapToZoomEnabled(false);
        initBarChart(barChart);
        setBarChartData(types.length, barChart);
        initView();
        initData();
       // barChart.setDescription("# of times Alice called Bob");


        return set;
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
    public int getAll() {
        ArrayList<Task> list = new ArrayList<>();
        SQLiteDatabase db = openHelper.getReadableDatabase();
        Cursor c = db.query("UnFinishedTasks", null, null, null, null, null, null);
        int colums = c.getColumnCount();
        while(c.moveToNext()) {
            Task task = new Task();
            // for (int i = 0; i < colums; i++) {
            String content = c.getString(c.getColumnIndex(c.getColumnName(1)));
            String date = c.getString(c.getColumnIndex(c.getColumnName(2)));
            task.setDate(date);
            task.setContent(content);
            list.add(task);
        }
        return list.size();
    }



    private void initBarChart(BarChart mBarChart) {
        mBarChart.setBackgroundColor(Color.WHITE);
        mBarChart.setDrawGridBackground(false); //网格
        mBarChart.getDescription().setEnabled(false);//描述
        //背景阴影
        mBarChart.setDrawBarShadow(false);

        //显示边界
        mBarChart.setDrawBorders(false);

        //设置动画效果
        mBarChart.animateY(1000, Easing.EasingOption.Linear);
        mBarChart.animateX(1000, Easing.EasingOption.Linear);

        //折线图例 标签 设置
        Legend l = mBarChart.getLegend();
        l.setEnabled(false);

        YAxis leftAxis = mBarChart.getAxisLeft();
        YAxis rightAxis = mBarChart.getAxisRight();
        leftAxis.setAxisMinimum(0f);
        rightAxis.setAxisMinimum(0f);
        leftAxis.setEnabled(false);
        rightAxis.setEnabled(false);

        XAxis xAxis = mBarChart.getXAxis();

        //XY轴的设置
        //X轴设置显示位置在底部
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        //xAxis.setGranularity(1f);

        //xAxis.setDrawAxisLine(true);
        xAxis.setDrawGridLines(false);
        //设置x轴坐标个数
        xAxis.setLabelCount(2);

        xAxis.setTextColor(0xff74828F);
        xAxis.setTextSize(10f);
        xAxis.setAxisLineColor(0xffe0e0e0);

        xAxis.setValueFormatter(new IAxisValueFormatter() {
            @Override
            public String getFormattedValue(float value, AxisBase axis) {
                int idx = (int) value;
                return types[idx];
            }
        });
    }

    private void setBarChartData(int count, BarChart mChart) {
        ArrayList<BarEntry> yVals = new ArrayList<>();

        int[] colors = new int[count];

        for (int i = 0; i < count; i++) {
            float val = changes[i];

            if (val > 0) {
                colors[i] = 0xffF04933;
            }

            if (val < 0) {
                colors[i] = 0xff2BBE53;
            }

            yVals.add(new BarEntry(i, Math.abs(val)));
        }

        BarDataSet mBarDataSet = new BarDataSet(yVals, "股票数据");
        mBarDataSet.setDrawIcons(false);
        mBarDataSet.setColors(colors);
        mBarDataSet.setValueTextSize(12f);
        mBarDataSet.setValueTextColor(0xff74828F);

        ArrayList<IBarDataSet> dataSets = new ArrayList<>();
        dataSets.add(mBarDataSet);

        BarData mBarData = new BarData(dataSets);
        mBarData.setBarWidth(0.6f);

        mBarData.setValueFormatter(new IValueFormatter() {
            @Override
            public String getFormattedValue(float value, Entry entry, int dataSetIndex, ViewPortHandler viewPortHandler) {
                int idx = (int) entry.getX();
                return String.valueOf(changes[idx]);
            }
        });
        mChart.setData(mBarData);
    }

    private void initData() {
        //创建数据源
        ArrayList<PieEntry> pieEntries = new ArrayList<>();
        pieEntries.add(new PieEntry(80.00f, "已完成"));
        pieEntries.add(new PieEntry(20.00f, "未完成"));

        //数据源设置
        PieDataSet pieDataSet = new PieDataSet(pieEntries, "");

        /**
         * 绘制外接线显示值（已注释）以下所示：
         */
//         pieDataSet.setValueLinePart1Length(1.0f);
//         pieDataSet.setValueLinePart2Length(0.1f);
//         pieDataSet.setValueLinePart1OffsetPercentage(100f);
//         pieDataSet.setValueLineColor(Color.GRAY);
//         pieDataSet.setXValuePosition(PieDataSet.ValuePosition.OUTSIDE_SLICE);
//         pieDataSet.setYValuePosition(PieDataSet.ValuePosition.OUTSIDE_SLICE);

        /**
         *  设置百分比格式（小数点后保留二位）：new PercentFormatter()
         */
        pieDataSet.setValueFormatter(new IValueFormatter() {
            @Override
            public String getFormattedValue(float v, Entry entry, int i, ViewPortHandler viewPortHandler) {
                DecimalFormat decimalFormat = new DecimalFormat("0.00");//保留两位小数
                String str = decimalFormat.format(v);
                return str;
            }
        });

        pieDataSet.setValueTextSize(18f);//值的字体大小
        pieDataSet.setValueTextColor(Color.WHITE);//值的颜色
        pieDataSet.setSelectionShift(6f);//点击弹出的距离(设置为0可不弹出)
        pieDataSet.setSliceSpace(3f);//扇形之间的间隙

        ArrayList<Integer> colors = new ArrayList<>();
        //颜色组合自己选（LIBERTY_COLORS或COLORFUL_COLORS...）
        for (int c : ColorTemplate.LIBERTY_COLORS) {
            colors.add(c);
        }
        pieDataSet.setColors(colors);

        Legend legend = pieChart.getLegend();
        legend.setForm(Legend.LegendForm.SQUARE);//正方形比例
        legend.setTextSize(12f);
        legend.setPosition(Legend.LegendPosition.RIGHT_OF_CHART_CENTER);//图表右中心

        /**
         * 装配数据
         */
        PieData pieData = new PieData(pieDataSet);
        pieChart.setData(pieData);
        pieChart.notifyDataSetChanged();
        pieChart.invalidate();
    }

    private void initView() {
        /**
         * 饼状图表（基本属性设置）
         */
      //  pieChart = findViewById(R.id.mPieChart);
        pieChart.getDescription().setEnabled(false);//没有描述
        pieChart.setNoDataText("加载中...");//加载数据时显示
        pieChart.setDrawHoleEnabled(false);//不绘制内圆（实心圆）
        pieChart.setUsePercentValues(true);//使用百分比值
        pieChart.setRotationEnabled(false);//不可手动旋转
        pieChart.setRotationAngle(0f);//绘制的时候，图表旋转角度。例如：-90f
        pieChart.setTouchEnabled(true);//可以点击
        pieChart.setExtraOffsets(30f, 30f, 15f, 30f);//设置左上右下间距
        pieChart.animateXY(1500, 1500);//动画
      //  pieChart.setTransparentCircleAlpha(110);
    }



}
