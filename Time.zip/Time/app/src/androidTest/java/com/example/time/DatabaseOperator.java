package com.example.time;

import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.database.sqlite.SQLiteDatabase;
import android.widget.EditText;
import android.widget.TableLayout;

import com.example.time.Bean.Task;
import com.example.time.DataBase.OpenHelper;

import java.util.ArrayList;
import java.util.Map;

public class DatabaseOperator {
    public void InsertUserSql(Task task, OpenHelper openHelper){
        String sql="insert into  UnFinishedTasks(content,date,priority,state) values(?,?,?,?)";

        //Gets the data repository in write mode*/
        SQLiteDatabase db = openHelper.getWritableDatabase();
        db.execSQL(sql,new Object[]{task.getContent(),task.getDate(),task.getPriority(),task.getState()});
    }

    public static void Insert(Task task,OpenHelper openHelper) {

        //Gets the data repository in write mode*/
        SQLiteDatabase db = openHelper.getWritableDatabase();

        // Create a new map of values, where column names are the keys
        ContentValues values = new ContentValues();
        values.put("content", task.getContent());
        values.put("date", task.getDate());
        values.put("priority", task.getPriority());
        values.put("state",task.getDate());

        // Insert the new row, returning the primary key value of the new row
        long newRowId;
        newRowId = db.insert(
                Task.Tasks.TABLE_NAME1,
                null,
                values);
    }


}
