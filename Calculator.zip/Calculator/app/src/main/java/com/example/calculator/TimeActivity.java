package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;

import java.text.DateFormat;
import java.util.Date;

public class TimeActivity extends AppCompatActivity{

    public Button btn1;
    public Button btn2;
    public Button days;
    Date date1;
    Date date2;
    String theDate1;
    String theDate2;
    long between;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_time);
        btn1=(Button)findViewById(R.id.startime);
        btn2=(Button)findViewById(R.id.endime);
        days=(Button)findViewById(R.id.days);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new DatePickerDialog(TimeActivity.this,new DatePickerDialog.OnDateSetListener()
                {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth)
                    {
                        theDate1=(String.format("%d-%d-%d",year,monthOfYear+1,dayOfMonth));
                        TextView text1=(TextView)findViewById(R.id.text1);
                        text1.setText("开始时间："+theDate1);
                        date1 = new Date(year - 1900, monthOfYear+1, dayOfMonth);//获取时间转换为Date对象
                    }
                },2016,4,11).show();
            }
        });
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new DatePickerDialog(TimeActivity.this,new DatePickerDialog.OnDateSetListener()
                {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth)
                    {
                        theDate2=(String.format("%d-%d-%d",year,monthOfYear+1,dayOfMonth));
                        TextView text2=(TextView)findViewById(R.id.text2);
                        text2.setText("结束时间："+theDate2);
                        date2= new Date(year - 1900, monthOfYear+1, dayOfMonth);
                    }
                },2016,4,11).show();
            }
        });
        days.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                between= DateUtil.getDaysBetween(date1,date2);
                TextView days=(TextView) findViewById(R.id.text3);
                days.setText("日期间隔为："+between+"天");
            }
        });

    }

}
