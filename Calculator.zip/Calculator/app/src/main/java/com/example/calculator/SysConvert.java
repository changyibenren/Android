package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class SysConvert extends AppCompatActivity {

    //转换前的单位
    Spinner spinner1;
    //转换后的单位
    Spinner spinner2;
    List<String> list1 = new ArrayList<String>();
    TextView editText1;
    TextView editText2;

    int firstChoice1 = 0;
    int secondChoice1 = 0;
    //选择第几个单位
    int CButton1 = 0;

    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sys_convert);
        spinner1 = (Spinner) findViewById(R.id.spinner1);
        spinner2 = (Spinner) findViewById(R.id.spinner2);
        editText1 = (TextView) findViewById(R.id.edittext1);
        editText2 = (TextView) findViewById(R.id.edittext2);

        Button button_six1 = (Button) findViewById(R.id.six1);
        Button button_seven1 = (Button) findViewById(R.id.seven1);
        Button button_eight1 = (Button) findViewById(R.id.eight1);
        Button button_nine1 = (Button) findViewById(R.id.nine1);
        Button button_two1 = (Button) findViewById(R.id.two1);
        Button button_three1 = (Button) findViewById(R.id.three1);
        Button button_four1 = (Button) findViewById(R.id.four1);
        Button button_five1 = (Button) findViewById(R.id.five1);
        Button button_one1 = (Button) findViewById(R.id.one1);
        Button button_zero1 = (Button) findViewById(R.id.zero1);
        Button button_changeTo1 = (Button) findViewById(R.id.changeTo1);
        Button button_c1 = (Button) findViewById(R.id.c1);
        Button button_delete1 = (Button) findViewById(R.id.delete1);
        Button button_a = (Button)findViewById(R.id.a);
        Button button_b = (Button)findViewById(R.id.b);
        Button button_c = (Button)findViewById(R.id.c);
        Button button_d = (Button)findViewById(R.id.d);
        Button button_e = (Button)findViewById(R.id.e);
        Button button_f = (Button)findViewById(R.id.f);


        button_six1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editText1.setText(editText1.getText() + "6");
            }
        });
        button_seven1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editText1.setText(editText1.getText() + "7");
            }
        });
        button_eight1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editText1.setText(editText1.getText() + "8");
            }
        });
        button_nine1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editText1.setText(editText1.getText() + "9");
            }
        });
        button_two1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editText1.setText(editText1.getText() + "2");
            }
        });
        button_three1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editText1.setText(editText1.getText() + "3");
            }
        });
        button_four1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editText1.setText(editText1.getText() + "4");
            }
        });
        button_five1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editText1.setText(editText1.getText() + "5");
            }
        });
        button_one1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editText1.setText(editText1.getText() + "1");
            }
        });
        button_zero1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editText1.setText(editText1.getText() + "0");
            }
        });
        button_a.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editText1.setText(editText1.getText()+"a");
            }
        });
        button_b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editText1.setText(editText1.getText()+"b");
            }
        });
        button_c.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editText1.setText(editText1.getText()+"c");
            }
        });
        button_d.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editText1.setText(editText1.getText()+"d");
            }
        });
        button_e.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editText1.setText(editText1.getText()+"e");
            }
        });
        button_f.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editText1.setText(editText1.getText()+"f");
            }
        });
        //转换
        button_changeTo1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editText2.setText(show(firstChoice1,secondChoice1));
            }
        });
        button_c1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editText1.setText("");
            }
        });
        button_delete1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                char[] cc = editText1.getText().toString().toCharArray();
                String ss = "";
                for(int i = 0;i<cc.length-1;i++){
                    ss = ss + cc[i];
                }
                editText1.setText(ss);
            }
        });

        list1.add("二进制");
        list1.add("八进制");
        list1.add("十进制");
        list1.add("十六进制");

        adapter = new ArrayAdapter<String>(SysConvert.this, android.R.layout.simple_spinner_item, list1);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner1.setAdapter(adapter);
        spinner2.setAdapter(adapter);

        spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                firstChoice1 = i;
                adapterView.setVisibility(View.VISIBLE);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                secondChoice1 = i;
                adapterView.setVisibility(View.VISIBLE);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }

    public String show(int f,int s){
        String result = null;
        if(f == 0){
            Integer n=Integer.valueOf(editText1.getText().toString(),2);
            if(s == 0){
               result=editText1.getText().toString();
            }
            else if(s == 1){
                //先转换为10进制，再转换为8进制
                //Integer n=Integer.valueOf(editText1.getText().toString(),2);
                result=Integer.toOctalString(n);
            }
            else if(s==2){
               // Integer n=Integer.valueOf(editText1.getText().toString(),2);
                result=String.valueOf(n);
            }
            else {
                result=Integer.toHexString(n);
            }
        }
        else if(f == 1){
            Integer n=Integer.valueOf(editText1.getText().toString(),8);
            if(s == 0){
               result=Integer.toBinaryString(n);
            }
            else if(s == 1){
                result=editText1.getText().toString();
            }
            else if(s==2){
                result=String.valueOf(n);
            }
            else {
                result=Integer.toHexString(n);
            }
        }
        else if(f==2){
            Integer n=Integer.valueOf(editText1.getText().toString());
            if(s == 0){
                result=Integer.toBinaryString(n);
            }
            else if(s == 1){
                result=Integer.toOctalString(n);
            }
            else if(s==2){
                result=editText1.getText().toString();
            }
            else {
                result=Integer.toHexString(n);
            }
        }
        else {
            Integer n=Integer.valueOf(editText1.getText().toString(),16);
            if(s == 0){
                result=Integer.toBinaryString(n);
            }
            else if(s == 1){
                result=Integer.toOctalString(n);
            }
            else if(s==2){
                result=String.valueOf(n);
            }
            else {
                result=editText1.getText().toString();
            }

        }
        return result;
    }
}
