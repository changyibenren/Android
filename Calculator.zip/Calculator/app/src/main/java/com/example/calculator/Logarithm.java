package com.example.calculator;

public class Logarithm {
    public static double log(double value,double base){
        return Math.log(value)/Math.log(base);
    }

}
