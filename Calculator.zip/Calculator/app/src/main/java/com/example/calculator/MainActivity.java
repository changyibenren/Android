package com.example.calculator;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Button;
import android.widget.Toast;

import com.example.calculator.R;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Stack;
public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    private TextView input;
    private TextView result;
    private StringBuilder str = new StringBuilder();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //R.attr.windowNoTitle=0;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //setContentView(R.layout.activity_main);
        input = (TextView) findViewById(R.id.input);
        result = (TextView) findViewById(R.id.result);
        Button zero = (Button) findViewById(R.id.number_0);
        Button one = (Button) findViewById(R.id.number_1);
        Button two = (Button) findViewById(R.id.number_2);
        Button three = (Button) findViewById(R.id.number_3);
        Button four = (Button) findViewById(R.id.number_4);
        Button five = (Button) findViewById(R.id.number_5);
        Button six = (Button) findViewById(R.id.number_6);
        Button seven = (Button) findViewById(R.id.number_7);
        Button eight = (Button) findViewById(R.id.number_8);
        Button nine = (Button) findViewById(R.id.number_9);
        Button cos = (Button) findViewById(R.id.cos);
        Button sin = (Button) findViewById(R.id.sin);
        Button tan = (Button) findViewById(R.id.tan);
        Button log10 = (Button) findViewById(R.id.log10);
        Button C = (Button) findViewById(R.id.C);
        //Button abs = (Button) findViewById(R.id.abs);
        Button Backspace = (Button) findViewById(R.id.backspace);
        Button divide = (Button) findViewById(R.id.divide);
        Button x1 = (Button) findViewById(R.id.x1);
        Button x2 = (Button) findViewById(R.id.x2);
        Button x3 = (Button) findViewById(R.id.x3);
        Button time = (Button) findViewById(R.id.time);
        Button multiply = (Button) findViewById(R.id.multiply);
        Button xabs = (Button) findViewById(R.id.xabs);
        Button jiecheng = (Button) findViewById(R.id.jiecheng);
        Button kaifang = (Button) findViewById(R.id.kaifang);
        Button jinzhi = (Button) findViewById(R.id.jinzhi);
        Button minus = (Button) findViewById(R.id.minus);
        Button pai = (Button) findViewById(R.id.pai);
        Button e = (Button) findViewById(R.id.e);
        Button ex = (Button) findViewById(R.id.ex);
        Button ln = (Button) findViewById(R.id.ln);
        Button add = (Button) findViewById(R.id.add);
        Button zuo = (Button) findViewById(R.id.zuokuo);
        Button you = (Button) findViewById(R.id.youkuo);
        Button baifenbi = (Button) findViewById(R.id.baifenbi);
        Button danwei = (Button) findViewById(R.id.danwei);
        Button dian = (Button) findViewById(R.id.xiaoshu);
        Button equal = (Button) findViewById(R.id.equal);
        // zero.setOnClickListener(listener);
        zero.setOnClickListener(this);
        one.setOnClickListener(this);
        two.setOnClickListener(this);
        three.setOnClickListener(this);
        four.setOnClickListener(this);
        five.setOnClickListener(this);
        six.setOnClickListener(this);
        seven.setOnClickListener(this);
        eight.setOnClickListener(this);
        nine.setOnClickListener(this);
        add.setOnClickListener(this);
        divide.setOnClickListener(this);
        minus.setOnClickListener(this);
        multiply.setOnClickListener(this);
        C.setOnClickListener(this);
        Backspace.setOnClickListener(this);
        dian.setOnClickListener(this);
        sin.setOnClickListener(this);
        cos.setOnClickListener(this);
        tan.setOnClickListener(this);
        x2.setOnClickListener(this);
        x3.setOnClickListener(this);
        equal.setOnClickListener(this);
        xabs.setOnClickListener(this);
        log10.setOnClickListener(this);
        jiecheng.setOnClickListener(this);
        kaifang.setOnClickListener(this);
        pai.setOnClickListener(this);
        e.setOnClickListener(this);
        ex.setOnClickListener(this);
        //ln.setOnClickListener(this);
        baifenbi.setOnClickListener(this);
        jinzhi.setOnClickListener(this);
        danwei.setOnClickListener(this);
        time.setOnClickListener(this);
        zuo.setOnClickListener(this);
        you.setOnClickListener(this);
        x1.setOnClickListener(this);
        ln.setOnClickListener(this);
        //Spinner spinner=(Spinner)findViewById(R.id.type);
    }



    @Override
    public void onClick(View view) {
        try {
            switch (view.getId()) {
                case R.id.C:
                    tvClear(input, result);
                    str.setLength(0);
                    break;
                case R.id.backspace:
                    int len = str.length();
                    if (len == 0) return;
                    input.setText(str.deleteCharAt(len - 1));
                    break;
                case R.id.sin:
                    //String hanshu = str.toString();
                    //double sina = Double.parseDouble(str.toString());
                    //double sinb = Math.toRadians(sina);
                    //double sinc = Math.sin(sinb);
                    str.append("sin(");
                    input.setText(str);
                    break;
                //System.out.println(sinc);
                //input.
                //break;
                case R.id.cos:
                    str.append("cos(");
                    input.setText(str);
                    break;
                case R.id.tan:
                    str.append("tan(");
                    input.setText(str);
                    break;
                case R.id.x2:
                    String s1=str.toString();
                    str=new StringBuilder(s1+"^2");
                    input.setText(str);
                    double x=Double.parseDouble(s1);
                    double x2=x*x;
                    String x2s = String.valueOf(x2);
                    // System.out.println(x2s);
                    str = new StringBuilder(x2s);
                    break;
                case R.id.x3:
                    String s2=str.toString();
                    double y=Double.parseDouble(s2);
                    double y3=Math.pow(y,3);
                    String y3s = String.valueOf(y3);
                    input.setText(s2+"^3");
                    str = new StringBuilder(y3s);
                    break;
                case R.id.x1:
                    String s9=str.toString();
                    double x1=Double.parseDouble(s9);
                    //  System.out.println(x1);
                    double r=Math.pow(x1,-1);
                    str=new StringBuilder(String.valueOf(r));
                    break;
                case R.id.time:
                    Intent time_intent=new Intent(MainActivity.this,TimeActivity.class);
                    startActivity(time_intent);
                    break;
                case R.id.xabs:
                    String s3=str.toString();
                    double z=Double.parseDouble(s3);
                    double abs=Math.abs(z);
                    String sabs=String.valueOf(abs);
                    str=new StringBuilder(sabs);
                    break;
                case R.id.log10:
                    String s4=str.toString();
                    double k=Double.parseDouble(s4);
                    double log=Logarithm.log(k,10);
                    String slog=String.valueOf(log);
                    str=new StringBuilder(slog);
                    break;
                case R.id.jiecheng:
                    String s5=str.toString();
                    double l=Double.parseDouble(s5);
                    double sum=1;
                    for(int j=1;j<=l;j++){
                        sum=sum*j;
                    }
                    String jiecheng=String.valueOf(sum);
                    str=new StringBuilder(jiecheng);
                    break;
                case R.id.kaifang:
                    String s6=str.toString();
                    double m=Double.parseDouble(s6);
                    double kai=Math.sqrt(m);
                    String skai=String.valueOf(kai);
                    str=new StringBuilder(skai);
                    break;
                case R.id.baifenbi:
                    String s8=str.toString();
                    double o=Double.parseDouble(s8);
                    double banfeibi=o/100;
                    String sbanfenbi=String.valueOf(banfeibi);
                    str=new StringBuilder(sbanfenbi);
                    break;
                case R.id.add:
                    symbolSolve("+");
                    input.setText(str);
                    return;
                case R.id.minus:
                    symbolSolve("-");
                    input.setText(str);
                    return;
                case R.id.multiply:
                    symbolSolve("*");
                    input.setText(str);
                    return;
                case R.id.divide:
                    symbolSolve("/");
                    input.setText(str);
                    return;
                case R.id.zuokuo:
                    symbolSolve("(");
                    input.setText(str);
                    return;
                case R.id.youkuo:
                    symbolSolve(")");
                    input.setText(str);
                    return;
                case R.id.pai:
                    str.append("π");
                    input.setText(str);
                case R.id.jinzhi:
                    Intent intent1=new Intent(MainActivity.this,SysConvert.class);
                    startActivity(intent1);
                    break;
                case R.id.danwei:
                    Intent intent=new Intent(MainActivity.this,UnitConversion.class);
                    startActivity(intent);
                    break;
                case R.id.ln:
                    String s7=str.toString();
                    double n=Double.parseDouble(s7);
                    double ln=Math.log(n);
                    String sln=String.valueOf(ln);
                    System.out.println(sln);
                    str=new StringBuilder(sln);
                    break;
                case R.id.e:
                    str=str.append("e");
                    input.setText(str);
                    break;
                case R.id.ex:
                    str=str.append("e^");
                    input.setText(str);
                    break;
                case R.id.equal:
                    if(str.indexOf("sin")!=-1){
                        int index = str.indexOf("sin(");
                        //System.out.println(index);
                        int end = str.length();
                        String numbers = str.substring(index+4);
                        //double inResult = calculate(numbers);//计算sin（）内的值
                        double b = Math.toRadians(Double.parseDouble(numbers));
                        double c = Math.sin(b);
                        //System.out.println(c);
                        //将sin括号后的一切替换为inResult的值
                        //str = new StringBuffer(numbers);
                        //str.replace(index,end,String.valueOf(c));
                        String sins = String.valueOf(c);
                        str = new StringBuilder(sins);
                        // result.setText(c+"");
                    }
                    if(str.indexOf("cos")!=-1){
                        int index = str.indexOf("cos(");
                        //System.out.println(index);
                        int end = str.length();
                        String numbers = str.substring(index+4);
                        //double inResult = calculate(numbers);//计算sin（）内的值
                        double b = Math.toRadians(Double.parseDouble(numbers));
                        double c = Math.cos(b);
                        //System.out.println(c);
                        //将sin括号后的一切替换为inResult的值
                        //str = new StringBuffer(numbers);
                        //str.replace(index,end,String.valueOf(c));
                        String coss = String.valueOf(c);
                        str = new StringBuilder(coss);
                        // result.setText(c+"");
                    }
                    if(str.indexOf("tan")!=-1){
                        int index = str.indexOf("tan(");
                        //System.out.println(index);
                        int end = str.length();
                        String numbers = str.substring(index+4);
                        //double inResult = calculate(numbers);//计算sin（）内的值
                        double b = Math.toRadians(Double.parseDouble(numbers));
                        double c = Math.tan(b);
                        //System.out.println(c);
                        //将sin括号后的一切替换为inResult的值
                        //str = new StringBuffer(numbers);
                        //str.replace(index,end,String.valueOf(c));
                        String tans = String.valueOf(c);
                        str = new StringBuilder(tans);
                        // result.setText(c+"");
                    }
                    if(str.indexOf("π")!=-1){
                        int index=str.indexOf("π");
                        String numbers = str.substring(0,index);
                        //System.out.println(numbers);
                        double c=Double.parseDouble(numbers);
                        c=c*3.14;
                        String tans = String.valueOf(c);
                        str = new StringBuilder(tans);
                    }
                    if(str.indexOf("e^")!=-1){
                        int index=str.indexOf("e^");
                        int mi=Integer.valueOf(str.substring(index+2));
                        System.out.println(mi);
                        double res=Math.pow(2.71,mi);
                        String numbers=String.valueOf(res);
                        str=new StringBuilder(numbers);
                    }
                    if(str.indexOf("e")!=-1){
                        String numbers=String.valueOf("2.7182818285");
                        str=new StringBuilder(numbers);
                    }
                    if (str.length() == 0) return;
                    if (str.length() == 1 && str.charAt(0) == '-') return;
                    DecimalFormat df = new DecimalFormat("###.###############");
                    String num = null;
                    double d = calculate(str.toString());
                    if (Double.isNaN(d) || Double.isInfinite(d)) {
                        result.setText("不能除以0");
                    } else {
                        try {
                            num = df.format(d);
                        } catch (Exception e) {
                            System.out.println("错误！");
                        }
                        result.setText("-0".equals(num) ? "0" : num);
                    }
                    result.setTextColor(Color.parseColor("#ff00ff"));
                    result.setTextSize(36);
                    return;

                case R.id.xiaoshu:
                    str.append(".");
                    break;
                case R.id.number_0:
                    str.append("0");
                    break;
                case R.id.number_1:
                    str.append("1");
                    break;
                case R.id.number_2:
                    str.append("2");
                    break;
                case R.id.number_3:
                    str.append("3");
                    break;
                case R.id.number_4:
                    str.append("4");
                    break;
                case R.id.number_5:
                    str.append("5");
                    break;
                case R.id.number_6:
                    str.append("6");
                    break;
                case R.id.number_7:
                    str.append("7");
                    break;
                case R.id.number_8:
                    str.append("8");
                    break;
                case R.id.number_9:
                    str.append("9");
                    break;
            }
            input.setText(str);

            int len = str.length();
            if (len != 0) {
                DecimalFormat df = new DecimalFormat("###.###############");
                String num = null;
                double d = calculate(str.toString());
                if (Double.isNaN(d) || Double.isInfinite(d)) {
                    result.setText("不能除以0");
                } else {
                    try {
                        num = df.format(d);
                    } catch (Exception e) {
                        System.out.println("错误！");
                    }
                    result.setText("-0".equals(num) ? "0" : num);
                }
            }
        } catch (NumberFormatException e) {
            // result.setText("");
            e.printStackTrace();
        }
    }

    private boolean isOperator(String s) {
        return s.equals("+")||s.equals("-")||s.equals("*")||s.equals("/");
    }

    public static boolean isNumber(String num){
        return num.matches("\\d+");
    }

    private void symbolSolve(String s) {
        int len = str.length();
        switch (s) {
            case "-":
                if (len == 0) {
                    str.append("-");
                    return;
                }
                if (str.charAt(len - 1) == '*' || str.charAt(len - 1) == '/') {
                    str.append(s);
                } else if (isOperator(str.charAt(len - 1) + "")) {
                    str.replace(len - 1, len, s);
                } else {
                    str.append(s);
                }
                break;
            case "+":
            case "*":
            case "/":
            case ")":
                if (len == 0) return;
                if (isOperator(str.charAt(len - 1) + "")) {
                    str.replace(len - 1, len, s);
                } else {
                    str.append(s);
                }
                break;
            case "(":
                str.append(s);
            /*case "(":
                //char t=str.charAt(len-1);
                if(len==0||isOperator(str.charAt(len-1) + "")){
                    str.append("(");
                }
                else if(str.charAt(len-1)>='0'&&str.charAt(len-1)<=9){
                    str.append("");
                }
                else if(str.charAt(len-1)=='.'||str.charAt(len-1)==')'){
                    str.append("");
                }
                break;
            case ")":
                int k=0;
                for(int j=0;j<=len-1;j++){
                    if(str.charAt(j)=='('){
                        k++;
                    }
                }
                k--;
                //System.out.println(k);
                if(len==0||isOperator(str.charAt(len - 1) + "")){
                    str.append("");
                }
                else if(str.charAt(len-1)>='0'&&str.charAt(len-1)<='9'||str.charAt(len-1)==')'){
                    if(k>=0)
                        str.append(")");
                }
                else if(str.charAt(len-1)=='.'){
                    str.append("");
                }
                break;*/
        }
    }



    private void tvClear(TextView input, TextView result) {
        input.setText("");
        result.setText("");
        result.setTextColor(Color.parseColor("#aaaaaa"));
        result.setTextSize(28);
    }

    private double calculate(String s) {
        List<String> houzhui=expressionToList(s);
        List<String> zhongzhui = parseToSuffixExpression(houzhui); // 中缀表达式转为后缀表达式
        return calculate(zhongzhui);
    }

    /**
     * 根据后缀表达式list计算结果
     * @param list
     * @return
     */
    private double calculate(List<String> list) {
        Stack<Double> stack = new Stack<>();
        for(int i=0; i<list.size(); i++){
            String item = list.get(i);
            double num1=0.0,num2=0.0;
            if(item.matches("\\d+")){
                //是数字
                stack.push(Double.parseDouble(item));
            }else {
                //是操作符，取出栈顶两个元素
                if (stack.isEmpty()) return 0.0;
                num2 = stack.pop();
                if (stack.isEmpty()) return num2;
                num1 = stack.pop();
                double res = 0.0;
                if(item.equals("+")){
                    res = num1 + num2;
                }else if(item.equals("-")){
                    res = num1 - num2;
                }else if(item.equals("*")){
                    res = num1 * num2;
                }else if(item.equals("/")){
                    res = num1 / num2;
                }else {
                    throw new RuntimeException("运算符错误！");
                }
                stack.push(res);
            }
        }
        return stack.pop();
    }

    /**
     * 将表达式转为list
     * @param expression
     * @return
     */
    private static List<String> expressionToList(String expression) {
        int index = 0;
        List<String> list = new ArrayList<>();
        do{
            char ch = expression.charAt(index);
            if(ch < 47 || ch > 58){
                //是操作符，直接添加至list中
                index ++ ;
                list.add(ch+"");
            }else if(ch >= 47 && ch <= 58){
                //是数字,判断多位数的情况
                String str = "";
                while (index < expression.length() && expression.charAt(index) >=47 && expression.charAt(index) <= 58){
                    str += expression.charAt(index);
                    index ++;
                }
                list.add(str);
            }
        }while (index < expression.length());
        return list;
    }

    // 获得后缀表达式
    private List<String> parseToSuffixExpression(List<String> expressionList) {
                 //创建一个栈用于保存操作符
                 Stack<String> opStack = new Stack<>();
                 //创建一个list用于保存后缀表达式
                 List<String> suffixList = new ArrayList<>();
                 for(String item : expressionList){
                         //得到数或操作符
                         if(isOperator(item)){
                                 //是操作符 判断操作符栈是否为空
                                 if(opStack.isEmpty() || "(".equals(opStack.peek()) || priority(item) > priority(opStack.peek())){
                                         //为空或者栈顶元素为左括号或者当前操作符大于栈顶操作符直接压栈
                                         opStack.push(item);
                                     }else {
                                         //否则将栈中元素出栈如队，直到遇到大于当前操作符或者遇到左括号时
                                         while (!opStack.isEmpty() && !"(".equals(opStack.peek())){
                                                 if(priority(item) <= priority(opStack.peek())){
                                                         suffixList.add(opStack.pop());
                                                     }
                                             }
                                         //当前操作符压栈
                                         opStack.push(item);
                                     }
                             }else if(isNumber(item)){
                                 //是数字则直接入队
                                 suffixList.add(item);
                             }else if("(".equals(item)){
                                 //是左括号，压栈
                                 opStack.push(item);
                             }else if(")".equals(item)){
                                 //是右括号 ，将栈中元素弹出入队，直到遇到左括号，左括号出栈，但不入队
                                 while (!opStack.isEmpty()){
                                         if("(".equals(opStack.peek())){
                                                 opStack.pop();
                                                 break;
                                             }else {
                                                 suffixList.add(opStack.pop());
                                             }
                                     }
                            }else {
                                throw new RuntimeException("有非法字符！");
                             }
                     }
                 //循环完毕，如果操作符栈中元素不为空，将栈中元素出栈入队
                 while (!opStack.isEmpty()){
                         suffixList.add(opStack.pop());
                     }
                 return suffixList;
    }


    public static int priority(String op){
                 if(op.equals("*") || op.equals("/")){
                         return 1;
                     }else if(op.equals("+") || op.equals("-")){
                         return 0;
                     }
                 return -1;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.menu_main,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        int id=item.getItemId();
        switch (id){
            case R.id.help:
                Toast.makeText(this,"help",Toast.LENGTH_LONG).show();
                break;
            case R.id.exit:
                MainActivity.this.finish();
        }
        return super.onOptionsItemSelected(item);
    }
}