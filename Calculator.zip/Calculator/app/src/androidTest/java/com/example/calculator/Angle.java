package com.example.calculator;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Angle extends AppCompatActivity implements View.OnClickListener{

    private int t=0;
    private EditText input;
    private TextView result;
    private Button cal;
    double r=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_angle);
        input=(EditText)findViewById(R.id.input);
        result=(TextView)findViewById(R.id.result);
        cal=(Button)findViewById(R.id.calc);
        cal.setOnClickListener(this);
        final Spinner spinner_result=(Spinner)findViewById(R.id.tijitype2);
        //ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, bulk);  //创建一个数组适配器
        //ArrayAdapter<String> adapter2 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, bulk);  //创建一个数组适配器
        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(this, R.array.items,android.R.layout.simple_spinner_dropdown_item);
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner_result.setAdapter(adapter2);
        spinner_result.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                String select=spinner_result.getItemAtPosition(i).toString();
                // Log.i("单位",select);
                switch (select){
                    case "立方厘米":t=1;break;
                    case "立方分米":t=2;break;
                    case "立方米":t=3;break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        final Spinner spinner_input=(Spinner)findViewById(R.id.tijitype1);
        ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(this, R.array.items,android.R.layout.simple_spinner_dropdown_item);
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);    //设置下拉列表框的下拉选项样式
        spinner_input.setAdapter(adapter1);
        //spinner_input.setAdapter(adapter1);
        spinner_input.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
                String select=spinner_input.getItemAtPosition(position).toString();
                //Log.i("单位",select);
                switch(select){
                    case "立方厘米":
                        if(t==1){
                            double shuru=Double.parseDouble(input.getText().toString());
                            r=shuru;
                        }
                        if(t==2){
                            double shuru=Double.parseDouble(input.getText().toString());
                            r=shuru/1000;
                        }
                        if(t==3){
                            double shuru=Double.parseDouble(input.getText().toString());
                            r=shuru/1000000;
                        }
                        break;
                    case "立方分米":
                        if(t==1){
                            double shuru=Double.parseDouble(input.getText().toString());
                            r=shuru*1000;
                        }
                        if(t==2){
                            double shuru=Double.parseDouble(input.getText().toString());
                            r=shuru;
                        }
                        if(t==3){
                            double shuru=Double.parseDouble(input.getText().toString());
                            r=shuru/1000;
                        }
                        break;
                    case "立方米":
                        if(t==1){
                            double shuru=Double.parseDouble(input.getText().toString());
                            r=shuru*1000000;
                        }
                        if(t==2){
                            double shuru=Double.parseDouble(input.getText().toString());
                            r=shuru*1000;
                        }
                        if(t==3){
                            double shuru=Double.parseDouble(input.getText().toString());
                            r=shuru;
                        }
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
            }

        });

    }
    @Override
    public void onClick(View view) {
        result.setText(r+"");
    }

}
