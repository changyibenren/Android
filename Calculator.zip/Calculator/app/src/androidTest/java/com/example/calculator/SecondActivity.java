package com.example.calculator;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import android.annotation.SuppressLint;


import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import org.w3c.dom.Text;

import static android.app.PendingIntent.getActivity;


public class SecondActivity extends AppCompatActivity implements View.OnClickListener{





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        Button btn_1=(Button)findViewById(R.id.btn_1);
        Button btn_2=(Button)findViewById(R.id.btn_2);
        Button btn_3=(Button)findViewById(R.id.btn_3);
        Button btn_4=(Button)findViewById(R.id.btn_4);
        btn_1.setOnClickListener(this);
        btn_2.setOnClickListener(this);
        btn_3.setOnClickListener(this);
        btn_4.setOnClickListener(this);

    }

    @Override
    public void onClick(View view){
        switch (view.getId()){
            case R.id.btn_1:
                Intent intent_volume=new Intent(SecondActivity.this,Volume.class);
                startActivity(intent_volume);
                break;
            case R.id.btn_2:
                Intent intent_length=new Intent(SecondActivity.this,Length.class);
                startActivity(intent_length);
                break;
            case R.id.btn_3:
                Intent intent_area=new Intent(SecondActivity.this,Area.class);
                startActivity(intent_area);
                break;
            case R.id.btn_4:
                Intent intent_angle=new Intent(SecondActivity.this,Angle.class);
                startActivity(intent_angle);
                break;


        }

    }
}